import {spawn,execFileSync} from 'node:child_process';
import {openSync,writeSync,closeSync} from 'node:fs';
import {writeFile,appendFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {Client} from 'pg';
const tier=process.argv[2],workOnly=process.argv[3]==='work-only'; assert(['standard','opt-in'].includes(tier));
const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
const root='codex-briefs/241-step3/'+tier+'-'+stamp;
const container='dfs-ev-demo-test-postgres-1';
const docker=(args)=>execFileSync('docker',args,{encoding:'utf8'}).trim();
const mount=()=>{const df=docker(['exec',container,'df','-Pk','/var/lib/postgresql']);const cols=df.split('\n').at(-1).trim().split(/\s+/);return{raw:df,mountBytes:Number(cols[1])*1024,usedBytes:Number(cols[2])*1024,availableBytes:Number(cols[3])*1024}};
const storage={...mount(),hostConfigTmpfs:JSON.parse(docker(['inspect',container,'--format','{{json .HostConfig.Tmpfs}}']))};
assert.equal(storage.mountBytes,tier==='standard'?536870912:2147483648);
const report={issue:241,step:3,tier,startedAt:new Date().toISOString(),verdict:'running',storage,runs:[],disk:[],failures:[]};
const maintenance=new Client({connectionString:process.env.TEST_DATABASE_URL});let child,backendFailure;
const save=()=>writeFile(root+'-validation.json',JSON.stringify(report,null,2)+'\n');
maintenance.on('error',error=>{backendFailure={message:error.message,code:error.code??null};report.failures.push(backendFailure);child?.kill('SIGTERM');void save();});
const disk=async label=>{
 const pg=(await maintenance.query(`SELECT clock_timestamp()::text AS at,(SELECT sum(size) FROM pg_ls_waldir()) AS wal_bytes,
 (SELECT coalesce(jsonb_agg(t),'[]') FROM pg_ls_tmpdir() t) AS temp_files,
 (SELECT jsonb_agg(jsonb_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database) AS databases,
 current_setting('max_wal_size') AS max_wal_size,current_setting('shared_buffers') AS shared_buffers,current_setting('work_mem') AS work_mem`)).rows[0];
 const snapshot={label,...pg,...mount()};report.disk.push(snapshot);await appendFile(root+'-disk.jsonl',JSON.stringify(snapshot)+'\n');
};
const run=async(name,files,evidence={})=>{
 const record={name,files,startedAt:new Date().toISOString(),verdict:'running',log:root+'-'+name+'.log'};report.runs.push(record);
 await disk(name+' before');await save();let pending=Promise.resolve(),observing=false,observerError;
 const monitor=setInterval(()=>{if(observing)return;observing=true;pending=disk(name+' in flight').catch(e=>{observerError={message:e.message,code:e.code??null};child?.kill('SIGTERM')}).finally(()=>observing=false)},1000);
 const fd=openSync(record.log,'wx');
 try{
  child=spawn(process.execPath,['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','--test','--test-concurrency=1',...files],{env:{...process.env,...evidence},stdio:['ignore','pipe','pipe']});
  child.stdout.on('data',b=>writeSync(fd,b));child.stderr.on('data',b=>writeSync(fd,b));
  record.exitCode=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve)});
 }finally{clearInterval(monitor);await pending;closeSync(fd);child=undefined;}
 Object.assign(record,{verdict:record.exitCode===0&&!observerError&&!backendFailure?'pass':'fail',observerError,finishedAt:new Date().toISOString()});
 if(!backendFailure)await disk(name+' after');await save();console.log(JSON.stringify(record));
 if(record.verdict!=='pass')throw new Error('Stopped at '+name+'; see durable log and disk JSONL');
};
try{
 await save();await maintenance.connect();
 if(tier==='standard'){
  await run('work',['services/pipeline/tests/feature-store/job-visibility-producer-work.check.mts'],{FEATURE_STORE_241_PRODUCER_WORK_PATH:root+'-work.json'});
  if(!workOnly){
  await run('behavior',['services/pipeline/tests/feature-store/job-visibility-producer.check.mts','services/pipeline/tests/feature-store/ingest.check.mts','services/pipeline/tests/feature-store/derived.check.mts'],{FEATURE_STORE_241_STEP3_EVIDENCE_PATH:root+'-behavior.json'});
  await run('compatibility',['services/pipeline/tests/feature-store/job-visibility-work.check.mts','services/pipeline/tests/feature-store/job-visibility-dataset.check.mts','services/pipeline/tests/feature-store/model-context.check.mts','services/pipeline/tests/feature-store/composite-authorization.check.mts','services/pipeline/tests/feature-store/model-artifacts.check.mts'],{FEATURE_STORE_241_WORK_EVIDENCE_PATH:root+'-dataset-work.json',FEATURE_STORE_241_STEP2_EVIDENCE_PATH:root+'-dataset-behavior.json'});
  }
 }else{
  await run('full-plan',['services/pipeline/tests/feature-store/job-visibility-producer-plan.mts'],{FEATURE_STORE_241_FULL_PLAN:'1',FEATURE_STORE_241_TMPFS_BYTES:String(storage.mountBytes),FEATURE_STORE_241_FULL_PLAN_PATH:root+'-full-plan.json'});
 }
 report.verdict='pass';
}catch(e){report.verdict='fail';report.error={message:e.message,code:e.code??null};process.exitCode=1;}
finally{
 report.finishedAt=new Date().toISOString();report.peakSampledUsedBytes=Math.max(...report.disk.map(r=>r.usedBytes),storage.usedBytes);report.sampling='one-second snapshots plus gate boundaries; sampled peak, not exact allocation peak';
 await maintenance.end().catch(()=>{});await save();console.log(JSON.stringify({verdict:report.verdict,root,peakSampledUsedBytes:report.peakSampledUsedBytes,mountBytes:storage.mountBytes}));
}
