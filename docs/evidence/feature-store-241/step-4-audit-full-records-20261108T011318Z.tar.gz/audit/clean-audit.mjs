import{mkdtemp,mkdir,cp,copyFile,writeFile}from'node:fs/promises';import{execFileSync}from'node:child_process';import{dirname}from'node:path';
const root=await mkdtemp('/private/tmp/dfs241-clean-audit-');
const paths=['services/pipeline/scripts/feature-store/artifact-governance-evidence.ts','services/pipeline/scripts/feature-store/prediction-capacity-evidence.ts','services/pipeline/scripts/feature-store/prediction-capacity-workload.ts','services/pipeline/scripts/feature-store/job-visibility-evidence.ts','services/pipeline/src/featureStore/objectStore.ts'];
for(const p of paths){await mkdir(dirname(root+'/'+p),{recursive:true});await copyFile(p,root+'/'+p)}
await cp('docs/evidence/feature-store-241',root+'/docs/evidence/feature-store-241',{recursive:true});
const out=execFileSync(process.execPath,['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','services/pipeline/scripts/feature-store/artifact-governance-evidence.ts','audit','docs/evidence/feature-store-241'],{cwd:root,encoding:'utf8'});
await writeFile('codex-briefs/241-step4/clean-audit.log',out);await writeFile('codex-briefs/241-step4/clean-audit.json',JSON.stringify({root,noNodeModules:true,noCache:true,records:out.trim().split('\n').length,verdict:'pass'},null,2)+'\n');console.log(JSON.stringify({root,verdict:'pass',records:out.trim().split('\n').length}));
