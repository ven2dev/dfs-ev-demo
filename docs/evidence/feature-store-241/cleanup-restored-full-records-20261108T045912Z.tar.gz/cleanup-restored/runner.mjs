import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {openSync,writeSync,closeSync} from 'node:fs';
import {writeFile,appendFile} from 'node:fs/promises';
import {Client} from 'pg';
const root='codex-briefs/241-cleanup/restored-'+new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
const mount=()=>{const raw=execFileSync('docker',['exec','dfs-ev-demo-test-postgres-1','df','-Pk','/var/lib/postgresql'],{encoding:'utf8'});const x=raw.trim().split('\n').at(-1).trim().split(/\s+/);return{mountBytes:Number(x[1])*1024,usedBytes:Number(x[2])*1024}};
assert.equal(mount().mountBytes,536870912);
const report={issue:241,step:'post-step-4-cleanup',root,runtime:process.version,startedAt:new Date().toISOString(),baseCommit:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),verdict:'running',runs:[],disk:[]};
const client=new Client({connectionString:process.env.TEST_DATABASE_URL});await client.connect();
const save=()=>writeFile(root+'-validation.json',JSON.stringify(report,null,2)+'\n');
const disk=async stage=>{const row={stage,...(await client.query(`SELECT clock_timestamp()::text AS at,(SELECT sum(size) FROM pg_ls_waldir()) AS wal_bytes,(SELECT coalesce(jsonb_agg(t),'[]') FROM pg_ls_tmpdir() t) AS temp_files,(SELECT jsonb_agg(jsonb_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database) AS databases,current_setting('max_wal_size') AS max_wal_size,current_setting('shared_buffers') AS shared_buffers,current_setting('work_mem') AS work_mem`)).rows[0],...mount()};report.disk.push(row);await appendFile(root+'-disk.jsonl',JSON.stringify(row)+'\n')};
let timer,pending=Promise.resolve(),busy=false,observerError;
const run=async(label,files,env)=>{const fd=openSync(root+'-'+label+'.log','wx');const p=spawn(process.execPath,['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','--test','--test-concurrency=1',...files],{env:{...process.env,...env},stdio:['ignore','pipe','pipe']});p.stdout.on('data',b=>writeSync(fd,b));p.stderr.on('data',b=>writeSync(fd,b));const exitCode=await new Promise((r,j)=>{p.once('error',j);p.once('close',r)});closeSync(fd);report.runs.push({label,files,exitCode});await save();console.log(JSON.stringify({label,exitCode,root}));assert.equal(exitCode,0,'stop after failed cleanup gate');};
try{await save();await disk('before');timer=setInterval(()=>{if(busy)return;busy=true;pending=disk('in-flight').catch(e=>observerError=String(e)).finally(()=>busy=false)},1000);
await run('plan',['services/pipeline/tests/feature-store/job-visibility-producer-work.check.mts'],{FEATURE_STORE_241_PRODUCER_WORK_PATH:root+'-plan.json'});
assert(!observerError);report.verdict='pass';
}catch(e){report.verdict='fail';report.error=String(e);process.exitCode=1;}finally{clearInterval(timer);await pending;await disk('after');report.cleanup=(await client.query(`SELECT (SELECT count(*)::integer FROM pg_database WHERE datname LIKE 'dfs_ev_test_%') AS scratch_databases,(SELECT count(*)::integer FROM pg_stat_activity WHERE datname LIKE 'dfs_ev_test_%') AS scratch_connections,(SELECT count(*)::integer FROM pg_roles WHERE rolcanlogin AND rolname NOT IN ('dfs_ev_test','postgres')) AS throwaway_logins`)).rows[0];await client.end();report.finishedAt=new Date().toISOString();report.peakSampledUsedBytes=Math.max(...report.disk.map(r=>r.usedBytes));await save();console.log(JSON.stringify({root,verdict:report.verdict,cleanup:report.cleanup,peakSampledUsedBytes:report.peakSampledUsedBytes}));}
