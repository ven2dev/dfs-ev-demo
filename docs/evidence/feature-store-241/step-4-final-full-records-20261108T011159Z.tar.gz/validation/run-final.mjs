import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
import {readFile,writeFile,appendFile} from 'node:fs/promises';
import {openSync,writeSync,closeSync} from 'node:fs';
import {Client} from 'pg';
const root='codex-briefs/241-step4/final-'+new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
const docker=args=>execFileSync('docker',args,{encoding:'utf8'});
const mount=()=>{const raw=docker(['exec','dfs-ev-demo-test-postgres-1','df','-Pk','/var/lib/postgresql']);const c=raw.trim().split('\n').at(-1).trim().split(/\s+/);return{mountBytes:Number(c[1])*1024,usedBytes:Number(c[2])*1024}};
assert.equal(mount().mountBytes,2147483648);
const report={issue:241,step:4,runtime:process.version,root,verdict:'running',mount:mount(),disk:[]};
const c=new Client({connectionString:process.env.TEST_DATABASE_URL});await c.connect();
const disk=async stage=>{const row={stage,...(await c.query(`SELECT clock_timestamp()::text AS at,(SELECT sum(size) FROM pg_ls_waldir()) AS wal_bytes,(SELECT coalesce(jsonb_agg(t),'[]') FROM pg_ls_tmpdir() t) AS temp_files,(SELECT jsonb_agg(jsonb_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database) AS databases,current_setting('max_wal_size') AS max_wal_size,current_setting('shared_buffers') AS shared_buffers,current_setting('work_mem') AS work_mem`)).rows[0],...mount()};report.disk.push(row);await appendFile(root+'-disk.jsonl',JSON.stringify(row)+'\n')};
const run=async(label,args,extra={})=>{const fd=openSync(root+'-'+label+'.log','wx');const child=spawn(process.execPath,args,{env:{...process.env,...extra},stdio:['ignore','pipe','pipe']});child.stdout.on('data',b=>writeSync(fd,b));child.stderr.on('data',b=>writeSync(fd,b));const code=await new Promise((r,j)=>{child.once('error',j);child.once('close',r)});closeSync(fd);console.log(JSON.stringify({label,code,log:root+'-'+label+'.log'}));assert.equal(code,0,label+' stops after failure');};
let timer,pending=Promise.resolve(),busy=false,err;
try{await disk('before');timer=setInterval(()=>{if(busy)return;busy=true;pending=disk('in-flight').catch(e=>err=e).finally(()=>busy=false)},1000);
await run('full-plan',['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','--test','--test-concurrency=1','services/pipeline/tests/feature-store/job-visibility-work.check.mts','services/pipeline/tests/feature-store/job-visibility-producer-plan.mts'],{FEATURE_STORE_241_FULL_DATASET:'1',FEATURE_STORE_241_FULL_PLAN:'1',FEATURE_STORE_241_TMPFS_BYTES:'2147483648',FEATURE_STORE_241_WORK_EVIDENCE_PATH:root+'-dataset-work.json',FEATURE_STORE_241_FULL_PLAN_PATH:root+'-producer-plan.json'});
await run('speed',['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','services/pipeline/scripts/feature-store/job-visibility-benchmark.ts'],{FEATURE_STORE_241_SPEED:'1',FEATURE_STORE_241_SPEED_DIRECTORY:root+'-speed'});
if(err)throw err;report.verdict='pass';
}catch(e){report.error=String(e);report.verdict='fail';process.exitCode=1;}finally{clearInterval(timer);await pending;await disk('after');await c.end();report.peakSampledUsedBytes=Math.max(...report.disk.map(d=>d.usedBytes));await writeFile(root+'-record.json',JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({root,verdict:report.verdict,peakSampledUsedBytes:report.peakSampledUsedBytes}));}
