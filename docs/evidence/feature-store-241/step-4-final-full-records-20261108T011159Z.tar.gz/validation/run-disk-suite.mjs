import assert from 'node:assert/strict';
import {readFile,writeFile,appendFile,readdir} from 'node:fs/promises';
import {openSync,writeSync,closeSync} from 'node:fs';
import {spawn,execFileSync} from 'node:child_process';
import {Client} from 'pg';
const label=process.argv[2],cwd=process.argv[3];assert(['main','branch','branch-reduced'].includes(label));assert(cwd);
const stamp=new Date().toISOString().replace(/[-:]/g,'').replace(/\.\d{3}Z$/,'Z');
const root='codex-briefs/241-step4/'+label+'-'+stamp;
const docker=(args)=>execFileSync('docker',args,{encoding:'utf8'}).trim();
const mount=()=>{const raw=docker(['exec','dfs-ev-demo-test-postgres-1','df','-Pk','/var/lib/postgresql']);const c=raw.split('\n').at(-1).trim().split(/\s+/);return{raw,mountBytes:Number(c[1])*1024,usedBytes:Number(c[2])*1024,availableBytes:Number(c[3])*1024}};
const storage=mount();assert.equal(storage.mountBytes,536870912);
const report={issue:241,step:4,kind:'standard-ci-disk',label,cwd,runtime:process.version,startedAt:new Date().toISOString(),verdict:'running',command:'npm run test:feature-store:db',storage,disk:[],failures:[]};
if(label==='main')report.sourceCommit=JSON.parse(await readFile('codex-briefs/241-step4/main-snapshot.json','utf8')).sha;else report.sourceCommit=execFileSync('git',['rev-parse','HEAD'],{cwd,encoding:'utf8'}).trim();
const save=()=>writeFile(root+'-record.json',JSON.stringify(report,null,2)+'\n');
const client=new Client({connectionString:process.env.TEST_DATABASE_URL});let child,backendFailure;
client.on('error',e=>{backendFailure={message:e.message,code:e.code??null};report.failures.push(backendFailure);child?.kill('SIGTERM');void save()});
const disk=async stage=>{const pg=(await client.query(`SELECT clock_timestamp()::text AS at,(SELECT sum(size) FROM pg_ls_waldir()) AS wal_bytes,
 (SELECT coalesce(jsonb_agg(t),'[]') FROM pg_ls_tmpdir() t) AS temp_files,
 (SELECT jsonb_agg(jsonb_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database) AS databases,
 current_setting('max_wal_size') AS max_wal_size,current_setting('shared_buffers') AS shared_buffers,current_setting('work_mem') AS work_mem`)).rows[0];const row={stage,...pg,...mount()};report.disk.push(row);await appendFile(root+'-disk.jsonl',JSON.stringify(row)+'\n')};
let observerError,pending=Promise.resolve(),observing=false,monitor;
try{
 await save();await client.connect();await disk('before');
 const files=(await readdir(cwd+'/services/pipeline/tests/feature-store')).filter(n=>n.endsWith('.check.mts')).sort();report.files=files;await save();
 const fd=openSync(root+'-suite.log','wx');
 try{
  monitor=setInterval(()=>{if(observing)return;observing=true;pending=disk('in flight').catch(e=>{observerError={message:e.message,code:e.code??null};child?.kill('SIGTERM')}).finally(()=>observing=false)},1000);
  child=spawn(process.execPath,['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON','--test','--test-concurrency=1',...files.map(n=>'services/pipeline/tests/feature-store/'+n)],{cwd,env:{...process.env,PATH:'/Users/vernonneilly/.nvm/versions/node/v24.18.1/bin:'+process.env.PATH},stdio:['ignore','pipe','pipe']});child.stdout.on('data',b=>writeSync(fd,b));child.stderr.on('data',b=>writeSync(fd,b));
  report.exitCode=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',resolve)});
 }finally{clearInterval(monitor);await pending;closeSync(fd);child=undefined;}
 if(!backendFailure)await disk('after');report.observerError=observerError;report.verdict=report.exitCode===0&&!observerError&&!backendFailure?'pass':'fail';
 const output=await readFile(root+'-suite.log','utf8');report.artifactCleanerFailed=/not ok.*artifact|✖.*artifact.*cleaner|artifact-cleaner\.check\.mts:[0-9]/i.test(output);console.log(output.slice(-2500));
 if(report.verdict!=='pass')process.exitCode=1;
}catch(e){report.verdict='fail';report.error={message:e.message,code:e.code??null};process.exitCode=1;}
finally{clearInterval(monitor);await pending;report.finishedAt=new Date().toISOString();report.peakSampledUsedBytes=Math.max(storage.usedBytes,...report.disk.map(r=>r.usedBytes));report.minimumSampledFreeFraction=1-report.peakSampledUsedBytes/storage.mountBytes;report.diskHeadroomBar=.25;report.diskHeadroomPass=report.minimumSampledFreeFraction>=.25;report.sampling='1 second and start/end boundaries; sampled rather than absolute peak';await client.end().catch(()=>{});await save();console.log(JSON.stringify({root,verdict:report.verdict,peakSampledUsedBytes:report.peakSampledUsedBytes,minimumSampledFreeFraction:report.minimumSampledFreeFraction,diskHeadroomPass:report.diskHeadroomPass}));}
