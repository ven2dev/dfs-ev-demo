import { evaluationCodeIdentity } from 'file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/scripts/feature-store/evaluation-fixture.ts';
import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { readFile,writeFile,mkdtemp,realpath,rm,mkdir } from "node:fs/promises";
import { cpus,totalmem,arch,platform,tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import type { ClientConfig } from "pg";
import { withFeatureStoreDatabase } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/scripts/feature-store/harness.ts";
import { ingestSource } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/ingest.ts";
import { runDerivedJob,FEATURE_VERSION,LABEL_VERSION,HISTORY_POLICY } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/derived.ts";
import { buildDataset,readDataset,DATASET_JOIN_SQL,type DatasetSpec } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/datasets.ts";
import { deleteSources,cleanupDeletedObjects,pruneDerivedVersions } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/governance.ts";
import { openLocalObjectStore } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/localObjectStore.ts";
import { sha256 } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/objectStore.ts";
import type { SourceAsset } from "file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/source.ts";
const root=new URL("file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/");
const reportPath=new URL("file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/codex-briefs/173-step3-20261109T080936Z/dataset-receipt.json");
const sourcePath=new URL('docs/evidence/feature-store-138/step-3-source-manifest.json',root);
const manifest=JSON.parse(await readFile(sourcePath,'utf8')) as {assets:{asset:SourceAsset}[]};
const previous=JSON.parse(await readFile(new URL('docs/evidence/feature-store-138/step-3-real-ingestion.json',root),'utf8')) as {storageRoot:string;results:{name:string;objectKey:string;wireSha256:string}[]};
const originals=await openLocalObjectStore(previous.storageRoot);
const storageRoot=await realpath(await mkdtemp(join("/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/codex-briefs/173-step3-20261109T080936Z",'dataset-objects-')));
const store=await openLocalObjectStore(storageRoot);
const files=['services/pipeline/src/featureStore/datasets.ts','services/pipeline/src/featureStore/governance.ts','services/pipeline/src/featureStore/derived.ts',
 'packages/db/proposals/138_feature_store.sql','packages/db/proposals/138_dataset_governance.sql','packages/db/proposals/163_effective_rights.sql','services/pipeline/scripts/feature-store/harness.ts',
 'services/pipeline/scripts/feature-store/dataset-spike.ts','services/pipeline/scripts/feature-store/dataset-cold.ts','services/pipeline/src/featureStore/objectStore.ts',
 'services/pipeline/src/featureStore/localObjectStore.ts','services/pipeline/src/featureStore/ingest.ts','services/pipeline/src/featureStore/normalize.ts','package-lock.json'];
const baseIdentity=await evaluationCodeIdentity();
files.push('packages/db/proposals/241_job_visibility.sql','services/pipeline/scripts/feature-store/fixture-proposals.ts','compose.test.yml');
const codeHashes={...baseIdentity.codeHashes,...Object.fromEntries(await Promise.all(files.map(async f=>[f,sha256(await readFile(new URL(f,root)))])))};
const code={gitSha:(await promisify(execFile)('git',['rev-parse','HEAD'])).stdout.trim(),contentSha256:sha256(Buffer.from(JSON.stringify(codeHashes)))};
const trials:Record<string,unknown>[]=[];
const setup:Record<string,unknown>[]=[];
const report:Record<string,unknown>={schemaVersion:1,issue:138,step:5,recordedAt:new Date().toISOString(),code,codeHashes,
 sourceManifestSha256:sha256(await readFile(sourcePath)),runtime:process.version,
 machine:{cpus:cpus().length,totalMemoryBytes:totalmem(),arch:arch(),platform:platform()},
 fixture:'exact step-3 raw objects, copied through ObjectStore to an isolated disposable root; no original objects deleted; no synthetic correction in real data',
 evidenceMode:'retrospective-reconstruction-v1',historicalAvailability:'unverified',scoringRun:false,
 cacheState:'three alternating fresh-process cold and warm builds; cold includes Node startup, new restricted connection, ObjectStore open, full join/write/hash; OS/DB caches not flushed',
 comparison:'absolute target only; no relative optimization or ABBA claim',
 deadlineMs:30000,headroomLimitMs:21000,setup,trials,verdict:'running'};
const diagnosticsRoot="/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/codex-briefs/173-step3-20261109T080936Z/dataset-diagnostics";
await mkdir(diagnosticsRoot,{recursive:true});
const diagnosticsPath=join(diagnosticsRoot,`dataset-${new Date().toISOString().replaceAll(':','-')}.json`);
const compactResult=(r:Record<string,unknown>)=>Object.fromEntries(Object.entries(r).filter(([k])=>!['authorization','delivery'].includes(k)));
const save=async()=>{
 const raw=JSON.stringify(report,null,2)+'\n';await writeFile(diagnosticsPath,raw);
 const compact={...report,setup:setup.map(r=>({name:r.name,status:r.status,wireSha256:r.wireSha256,rawRows:r.rawRows,normalizedRows:r.normalizedRows})),
  trials:trials.map(t=>({...t,result:t.result?compactResult(t.result as Record<string,unknown>):undefined})),
  rights:undefined,datasetPlan:undefined,sampleRows:undefined,snapshots:undefined,
  fullDiagnostics:{path:diagnosticsPath,sha256:sha256(Buffer.from(raw)),byteSize:Buffer.byteLength(raw)}};
 await writeFile(reportPath,JSON.stringify(compact,null,2)+'\n');
};await save();
try{await withFeatureStoreDatabase(async({admin,writer,reader,createWriterConfig,queryCounts})=>{
 report.database=(await admin.query('SELECT version() AS version')).rows[0].version;
 for(const {asset} of manifest.assets){
  const previousObject=previous.results.find(r=>r.name===asset.name);assert(previousObject);
  const bytes=await originals.get(previousObject.objectKey);assert.equal(sha256(bytes),previousObject.wireSha256);
  const receipt=await ingestSource(writer,store,asset,code,{download:async()=>({bytes,capturedAt:new Date().toISOString(),requests:0})});
  assert.equal(receipt.status,'ingested');setup.push({name:asset.name,...receipt});console.log(JSON.stringify({setup:asset.name,status:receipt.status}));await save();
 }
 // Local research permission only, supported by the owner's approved spike.
 // This is not a commercial license/availability qualification.
 report.rights=(await writer.query(`INSERT INTO fs138.rights_decisions(profile_id,allowed_uses,valid_from,rationale)
  SELECT profile_id,ARRAY['research'],clock_timestamp(),'owner-approved #138 local retrospective research; no commercial clearance claim'
  FROM fs138.source_profiles RETURNING decision_id,profile_id,recorded_at::text,allowed_uses`)).rows;
 const mode='retrospective-reconstruction-v1' as const;
 const derived=[];
 for(const season of [2021,2022,2023,2024,2025])for(const kind of ['features','labels'] as const){
  const result=await runDerivedJob(writer,kind,{season,mode},code);assert.equal(result.status,'succeeded');derived.push({season,kind,...result});
  report.derivedSetup=derived;await save();console.log(JSON.stringify({derived:kind,season,elapsedMs:result.elapsedMs}));
 }
 report.derivedSetup=derived;await save();
 const clock=async()=>(await admin.query('SELECT clock_timestamp()::text AS clock')).rows[0].clock as string;
 const selectionClock=await clock();
 const spec:DatasetSpec={mode,featureVersion:FEATURE_VERSION,labelVersion:LABEL_VERSION,historyPolicy:HISTORY_POLICY,
  featuresAsOf:selectionClock,labelsAsOf:selectionClock,includeRetrospective:true,includeSuperseded:true};report.spec=spec;
 report.datasetPlan=(await admin.query('EXPLAIN (FORMAT JSON) '+DATASET_JOIN_SQL,
  [spec.featureVersion,spec.labelVersion,spec.historyPolicy,spec.mode,spec.featuresAsOf,spec.labelsAsOf,spec.includeRetrospective,spec.includeSuperseded])).rows;
 await save();
 let last:Awaited<ReturnType<typeof buildDataset>>;
 const cold=async(config:ClientConfig)=>new Promise<{result:Awaited<ReturnType<typeof buildDataset>>;statements:number;rightsQueries:number;processId:number;peakRssBytes:number}>((resolve,reject)=>{
  const child=execFile(process.execPath,['--disable-warning=MODULE_TYPELESS_PACKAGE_JSON',fileURLToPath(new URL("file:///Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/scripts/feature-store/dataset-cold.ts"))],{maxBuffer:1024*1024},(error,stdout)=>{
   if(error)reject(error);else{try{resolve(JSON.parse(stdout));}catch(error){reject(error);}}
  });child.stdin!.end(JSON.stringify({config,spec,code,storageRoot}));
 });
 let warmRightsQueries=0;
 const measuredWriter=new Proxy(writer,{get(target,property){
  if(property!=='query')return Reflect.get(target,property,target);
  return(...args:unknown[])=>{const q=args[0];const sql=typeof q==='string'?q:(q as {text:string}).text;
   if(sql.includes('decisions AS MATERIALIZED'))warmRightsQueries++;
   return Reflect.apply(target.query,target,args);
  };
 }});
 for(let trial=1;trial<=3;trial++)for(const mode of ['cold','warm'] as const){
  const config=mode==='cold'?await createWriterConfig():null;
  const before=queryCounts.writer;const rightsBefore=warmRightsQueries;const started=performance.now();let entry:Record<string,unknown>;
  try{
   const receipt=config?await cold(config):{result:await buildDataset(measuredWriter,store,spec,code),statements:queryCounts.writer-before,rightsQueries:warmRightsQueries-rightsBefore,processId:process.pid,peakRssBytes:process.resourceUsage().maxRSS*1024};
   last=receipt.result;const measuredMs=performance.now()-started;
   entry={trial,mode,...receipt,measuredMs,verdict:measuredMs<=21000&&receipt.statements===8&&receipt.rightsQueries===2?'pass':'fail'};
  }catch(error){entry={trial,mode,error:String(error),measuredMs:performance.now()-started,verdict:'fail'};}
  trials.push(entry);await save();console.log(JSON.stringify({trial,mode,measuredMs:entry.measuredMs,verdict:entry.verdict,statements:entry.statements,rowCount:(entry.result as {rowCount:number}|undefined)?.rowCount,error:entry.error}));if(entry.verdict!=='pass')throw new Error('dataset-trial-failed; retained; stop without retry');
 }
 const bytes=await readDataset(reader,store,last!.datasetId);assert.equal(sha256(bytes),last!.fileSha256);
 const dataset=JSON.parse(bytes.toString()) as {rows:{season:number;sampleSize:number;history:{gameId:string;kickoff:string}[];gameId:string;cutoff:string;label:number;flags:string[]}[]};
 assert.equal(dataset.rows.length,2504);assert(dataset.rows.every(r=>r.season>=2022));
 report.coverage=[2022,2023,2024,2025].map(season=>({season,rows:dataset.rows.filter(r=>r.season===season).length,
  strata:Object.fromEntries([[2,4],[5,8],[9,16]].map(([lo,hi])=>[`${lo}-${hi}`,dataset.rows.filter(r=>r.season===season&&r.sampleSize>=lo&&r.sampleSize<=hi).length]))}));
 report.eventTimeLeaks=dataset.rows.filter(r=>r.history.some(h=>h.gameId===r.gameId||Date.parse(h.kickoff)>=Date.parse(r.cutoff))).length;
 report.hashParity=new Set(trials.map(t=>(t.result as {fileSha256:string})?.fileSha256)).size===1;
 report.contentHashParity=new Set(trials.map(t=>(t.result as {contentSha256:string})?.contentSha256)).size===1;
 report.sampleRows=[2,5,9].map(min=>dataset.rows.find(r=>r.sampleSize>=min));
 report.storage=(await admin.query('SELECT pg_database_size(current_database())::text AS database_bytes')).rows[0];
 report.targetVerdict=trials.length===6&&trials.every(t=>t.verdict==='pass')&&report.hashParity===true&&report.contentHashParity===true?'pass':'fail';
 report.verdict=report.targetVerdict==='pass'&&report.eventTimeLeaks===0?'step-5-local-dataset-rights-deletion-pass':'fail';
 });}catch(error){report.verdict='fail';report.error=String(error);throw error;}
finally{report.peakRssBytes=process.resourceUsage().maxRSS*1024;await save();}
console.log(JSON.stringify({report:reportPath.pathname,verdict:report.verdict}));
if(report.verdict!=='step-5-local-dataset-rights-deletion-pass')process.exitCode=1;
