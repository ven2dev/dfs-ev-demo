import difflib, hashlib, json
from datetime import datetime, timezone
from pathlib import Path

root = Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164')
stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
out = root / ('codex-briefs/173-step3-' + stamp)
out.mkdir(mode=0o700)
original = root / 'services/pipeline/scripts/feature-store/dataset-spike.ts'
text = original.read_text()
changes = []
def replace(old, new, reason):
    global text
    assert text.count(old) == 1, (reason, text.count(old))
    text = text.replace(old, new)
    changes.append(reason)

# Only the disposable driver's locations/setup identity/stop boundary change.
# Timed builds still call the original buildDataset and dataset-cold worker.
import re
text = re.sub(r'from "(\.[^"]+)"', lambda m: 'from "' + (original.parent / m[1]).resolve().as_uri() + '"', text)
text = text.replace('type SourceAsset } from', 'type SourceAsset } from')
text = "import { evaluationCodeIdentity } from '" + (original.parent / 'evaluation-fixture.ts').as_uri() + "';\n" + text
changes.append('Resolve imports to the unchanged committed modules from a disposable driver location')
replace("const root=new URL('../../../../',import.meta.url);", 'const root=new URL(' + json.dumps(root.as_uri() + '/') + ');', 'Keep repository/fixture root pinned to original checkout')
replace("const reportPath=new URL('docs/evidence/feature-store-138/step-5-real-dataset.json',root);", 'const reportPath=new URL(' + json.dumps((out / 'dataset-receipt.json').as_uri()) + ');', 'Redirect historical receipt to a new private output')
replace("const storageRoot=await realpath(await mkdtemp(join(tmpdir(),'dfs138-dataset-real-')));", 'const storageRoot=await realpath(await mkdtemp(join(' + json.dumps(str(out)) + ",'dataset-objects-')));", 'Retain isolated ObjectStore for current rerun records')
replace("const codeHashes=Object.fromEntries(await Promise.all(files.map(async f=>[f,sha256(await readFile(new URL(f,root)))])));", "const baseIdentity=await evaluationCodeIdentity();\nfiles.push('packages/db/proposals/241_job_visibility.sql','services/pipeline/scripts/feature-store/fixture-proposals.ts','compose.test.yml');\nconst codeHashes={...baseIdentity.codeHashes,...Object.fromEntries(await Promise.all(files.map(async f=>[f,sha256(await readFile(new URL(f,root)))])))};", 'Pin broad current source inventory including loaded #241 proposal and compose tier')
replace("const diagnosticsRoot=fileURLToPath(new URL('../dfs-ev-demo-138-data/step-5-diagnostics/',root));", 'const diagnosticsRoot=' + json.dumps(str(out / 'dataset-diagnostics')) + ';', 'Keep detailed diagnostics inside the writable private output')
replace("new URL('dataset-cold.ts',import.meta.url)", 'new URL(' + json.dumps((original.parent / 'dataset-cold.ts').as_uri()) + ')', 'Use unchanged committed fresh-process worker')
replace("if(entry.error)throw new Error('dataset-trial-failed');", "if(entry.verdict!=='pass')throw new Error('dataset-trial-failed; retained; stop without retry');", 'Stop immediately after saving any error, timing or work-budget failure')
start = text.index(" report.snapshots=")
end = text.index(" report.storage=", start)
text = text[:start] + text[end:]
changes.append('Omit historical deletion/rebuild probes after the six-sample matrix; #173 only renews capacity')
replace("await save();await rm(storageRoot,{recursive:true,force:true});", 'await save();', 'Keep private ObjectStore until receipt/artifact verification and durable evidence packaging')
text = text.replace('local research; no commercial clearance claim', '#173 local research; no commercial clearance claim')
(out / 'dataset-driver.mts').write_text(text)
(out / 'dataset-driver-original.ts').write_bytes(original.read_bytes())
(out / 'dataset-driver.diff').write_text(''.join(difflib.unified_diff(original.read_text().splitlines(True), text.splitlines(True), fromfile='committed/dataset-spike.ts', tofile='disposable/dataset-driver.mts')))
metadata = {'output': str(out), 'originalDriverSha256': hashlib.sha256(original.read_bytes()).hexdigest(), 'adaptedDriverSha256': hashlib.sha256(text.encode()).hexdigest(), 'changes': changes, 'timedBuild': 'unchanged buildDataset / dataset-cold.ts; original process and connection boundaries', 'scope': 'qualification only; no runtime or tracked driver edits'}
(out / 'driver-adaptation.json').write_text(json.dumps(metadata, indent=2) + '\n')
Path('/private/tmp/dfs173-step3-output').write_text(str(out))
print(json.dumps(metadata))
