import hashlib, json, os, subprocess, sys
from datetime import datetime, timezone
from pathlib import Path

root = Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164')
out = Path('/private/tmp/dfs173-step3-output').read_text().strip()
out = Path(out)
node = '/Users/vernonneilly/.nvm/versions/node/v24.18.1/bin/node'
env = dict(os.environ, DB_TEST_LANE='lane-3', DB_TEST_TIER='standard')
env['PATH'] = str(Path(node).parent) + ':' + env['PATH']
env['FS242_BENCHMARK_DIRECTORY'] = str(out / 'prediction')
env.pop('FS168_BENCHMARK_DIRECTORY', None)
env.pop('TEST_DATABASE_URL', None)
record = {'issue': 173, 'step': 3, 'ownerQuietWindow': 'Explicit owner confirmation: window is quiet; Codex ALT holding', 'checkpoint': '286f4d05d5d1eb34ec085a1a772f7e21afb40a27', 'sourceCommit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(), 'lane': 'lane-3', 'tier': 'standard', 'commands': [], 'verdict': 'running'}
def save():
    (out / 'orchestration.json').write_text(json.dumps(record, indent=2) + '\n')
def run(name, command, capture=False):
    row = {'name': name, 'command': command, 'startedAt': datetime.now(timezone.utc).isoformat()}
    record['commands'].append(row)
    save()
    print(json.dumps({'stage': name, 'status': 'started'}), flush=True)
    with (out / (name + '.log')).open('wb') as log:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        chunks = []
        for line in process.stdout:
            log.write(line); log.flush()
            chunks.append(line)
            if not capture:
                sys.stdout.buffer.write(line); sys.stdout.flush()
        code = process.wait()
    data = b''.join(chunks)
    row.update(exitCode=code, finishedAt=datetime.now(timezone.utc).isoformat(), sha256=hashlib.sha256(data).hexdigest(), byteSize=len(data), path=name+'.log')
    save()
    if code:
        raise RuntimeError(name + ' failed; retained; no retries')
    return data

save()
failed = False
cleanup_failed = False
try:
    assert not subprocess.check_output(['git','status','--porcelain'], cwd=root).strip(), 'tracked-source-not-clean'
    env['TEST_DATABASE_URL'] = run('derive-url', [node, 'scripts/db/test-db.mjs', 'url'], capture=True).decode().strip()
    run('lane-up', [node, 'scripts/db/test-db.mjs', 'up'])
    run('lane-inspect', ['docker', 'inspect', 'dfs-ev-demo-test-lane-3-postgres-1'], capture=True)
    run('prediction-preflight', [node, 'scripts/db/test-db.mjs', 'preflight'])
    run('prediction-qualification', [node, '--disable-warning=MODULE_TYPELESS_PACKAGE_JSON', 'services/pipeline/scripts/feature-store/prediction-benchmark.ts', '--capacity'])
    full = list((out / 'prediction').glob('qualification-*/full-samples.json'))
    assert len(full) == 1
    prediction = json.loads(full[0].read_text())
    assert prediction['verdict'] == 'pass' and len(prediction['samples']) == 600 and len(prediction['trials']) == 6
    run('dataset-preflight', [node, 'scripts/db/test-db.mjs', 'preflight'])
    run('dataset-qualification', [node, '--disable-warning=MODULE_TYPELESS_PACKAGE_JSON', str(out / 'dataset-driver.mts')])
    dataset = json.loads((out / 'dataset-receipt.json').read_text())
    assert dataset['targetVerdict'] == 'pass' and len(dataset['trials']) == 6
    record['verdict'] = 'pass'
except BaseException as error:
    failed = True
    record['verdict'] = 'fail'
    record['error'] = str(error)
    print(json.dumps({'stopped': str(error)}), flush=True)
finally:
    try:
        run('lane-down', [node, 'scripts/db/test-db.mjs', 'down'])
        remaining = run('verify-lane-containers', ['docker', 'ps', '--all', '--filter', 'label=com.docker.compose.project=dfs-ev-demo-test-lane-3', '--format', '{{.Names}}'], capture=True)
        networks = run('verify-lane-networks', ['docker', 'network', 'ls', '--filter', 'label=com.docker.compose.project=dfs-ev-demo-test-lane-3', '--format', '{{.Name}}'], capture=True)
        assert not remaining.strip() and not networks.strip(), 'lane-3-resources-remain'
        record['teardownVerified'] = True
    except BaseException as error:
        cleanup_failed = True
        record['cleanupError'] = str(error)
        record['verdict'] = 'fail'
    record['finishedAt'] = datetime.now(timezone.utc).isoformat()
    save()
    print(json.dumps({'verdict': record['verdict'], 'teardownVerified': record.get('teardownVerified'), 'output': str(out)}), flush=True)
if failed or cleanup_failed:
    raise SystemExit(1)
