import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164')
node = Path('/Users/vernonneilly/.nvm/versions/node/v24.18.1/bin/node')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
directory = root / 'codex-briefs' / ('173-step2-' + stamp)
directory.mkdir(mode=0o700)
env = dict(os.environ)
env['PATH'] = str(node.parent) + os.pathsep + env['PATH']
for key in ['NODE_OPTIONS','NODE_COMPILE_CACHE','FS168_BENCHMARK_DIRECTORY','FS242_BENCHMARK_DIRECTORY']:
    env.pop(key,None)
checks=[]
commands=[('audit-'+str(n),[str(node),'--disable-warning=MODULE_TYPELESS_PACKAGE_JSON',
  'services/pipeline/scripts/feature-store/artifact-governance-evidence.ts','audit',f'docs/evidence/feature-store-{n}'])
  for n in [166,231,167,168,241,242,169]]
commands.append(('offline-evidence-tests',[str(node),'--disable-warning=MODULE_TYPELESS_PACKAGE_JSON',
  '--test','--test-concurrency=1',*[f'services/pipeline/tests/feature-store/{name}.check.mts' for name in [
    'artifact-evidence','composite-evidence','prediction-evidence','prediction-owner-evidence',
    'prediction-capacity-evidence','producer-capacity-evidence']]]))
for name,command in commands:
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    result=subprocess.run(command,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    path=directory/(name+'.log')
    path.write_bytes(result.stdout)
    entry={'name':name,'command':command,'startedAt':started,'exitCode':result.returncode,
      'path':str(path.relative_to(root)),'sha256':hashlib.sha256(result.stdout).hexdigest(),
      'byteSize':len(result.stdout)}
    if name.startswith('audit-') and result.returncode==0:
        records=[json.loads(x) for x in result.stdout.splitlines() if x.startswith(b'{')]
        assert records and all(x['verdict']=='pass' for x in records)
        entry['records']=len(records)
    elif name=='offline-evidence-tests':
        entry['summary']=[x for x in result.stdout.decode().splitlines() if any(x.startswith(y) for y in ['ℹ tests','ℹ pass','ℹ fail','ℹ skipped','ℹ cancelled'])]
    checks.append(entry)
    print(json.dumps(entry),flush=True)
    (directory/'checks.json').write_text(json.dumps({'node':subprocess.check_output([str(node),'--version'],text=True).strip(),
      'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
      'checks':checks,'allPass':all(x['exitCode']==0 for x in checks)},indent=2)+'\n')
    if result.returncode:
        raise SystemExit(result.returncode)
print(json.dumps({'directory':str(directory.relative_to(root)),'allPass':True}),flush=True)
