import assert from 'node:assert/strict';
import { lstat, readFile, realpath, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { openLocalObjectStore } from '/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/localObjectStore.ts';
import { sha256, OBJECT_NAMESPACES } from '/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164/services/pipeline/src/featureStore/objectStore.ts';

const repository = '/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164';
const out = join(repository, 'codex-briefs/173-step2-20261109T074644Z/report-artifacts.json');
const readJson = async (path: string) => JSON.parse(await readFile(join(repository, path), 'utf8'));
const correction = await readJson('docs/evidence/feature-store-164/calibration-correction.json');
const evaluation = await readJson('docs/evidence/feature-store-164/step-3-evaluation.json');
const directory = correction.proof.storageRoot;
const result: Record<string, unknown> = { scope: 'Read-only verification through local ObjectStore; no rescoring, DB query or timing renewal', storageRoot: directory };
try {
  // Refuse absent namespaces before opening; the adapter then encounters existing
  // directories only. No reconstruction or writes to historical storage.
  assert.equal(await realpath(directory), directory);
  for (const namespace of OBJECT_NAMESPACES) assert((await lstat(join(directory, namespace))).isDirectory());
  const store = await openLocalObjectStore(directory);
  const references = [correction.proof.fullProofArtifact, correction.proof.verifierArtifact, ...evaluation.reports.map((r: {artifact: unknown}) => r.artifact)];
  const objects = [];
  for (const expected of references) {
    const bytes = await store.get(expected.objectKey);
    assert.equal(bytes.length, expected.byteSize);
    assert.equal(sha256(bytes), expected.sha256);
    const row: Record<string, unknown> = { ...expected, verified: true };
    const reportPin = evaluation.reports.find((r: {artifact: {objectKey: string}}) => r.artifact.objectKey === expected.objectKey);
    if (reportPin) {
      const body = JSON.parse(bytes.toString());
      assert.equal(sha256(Buffer.from(JSON.stringify(body.report))), reportPin.logicalSha256);
      assert.equal(body.logicalSha256, reportPin.logicalSha256);
      assert.equal(body.report.folds.length, reportPin.folds);
      row.logicalSha256 = reportPin.logicalSha256;
      row.folds = reportPin.folds;
      row.evidenceMode = reportPin.evidenceMode;
    }
    objects.push(row);
  }
  result.status = 'pass';
  result.objects = objects;
} catch (error) {
  result.status = 'unverified';
  result.error = { name: (error as Error).name, message: (error as Error).message };
}
await writeFile(out, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result));
