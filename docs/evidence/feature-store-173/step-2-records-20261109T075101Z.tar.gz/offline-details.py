import hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path

root = Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-164')
out = root / 'codex-briefs/173-step2-20261109T074644Z'
os.chdir(root)
digest = lambda b: hashlib.sha256(b).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
result = {'scope': 'Offline retained-byte, wrapper and cross-record consistency checks; no database re-execution', 'startedAt': datetime.now(timezone.utc).isoformat()}
index = load('docs/evidence/feature-store-138/archive-index.json')
archived = []
for name, expected in index['archivedFiles'].items():
    data = subprocess.check_output(['git', 'show', index['archiveCommit'] + ':docs/evidence/feature-store-138/' + name])
    row = {'file': name, 'sha256': digest(data), 'bytes': len(data), 'lines': len(data.splitlines())}
    assert all(row[k] == expected[k] for k in ('sha256', 'bytes', 'lines')), row
    archived.append(row)
result['archive138'] = {'commit': index['archiveCommit'], 'records': archived, 'allMatch': True}
correction = load('docs/evidence/feature-store-164/calibration-correction.json')
for name, expected in correction['evidence'].items():
    data = Path('docs/evidence/feature-store-164', name).read_bytes()
    assert digest(data) == expected['sha256'] and len(data) == expected['byteSize'], name
result['calibrationReceiptReferences'] = {'records': 3, 'allMatch': True}
wrapper170 = load('docs/evidence/feature-store-170/checkpoint-4-qualification.json')
p170 = Path('docs/evidence/feature-store-170', wrapper170['machineReceipt']['file'])
assert digest(p170.read_bytes()) == wrapper170['machineReceipt']['sha256']
r170 = load(p170)
assert r170['status'] == 'range-verified' and r170['counts']['verifiedObjects'] == 16
assert r170['counts']['verifiedWireBytes'] == 246304787
assert r170['initial']['stateSha256'] == r170['final']['stateSha256']
result['scrub170'] = {'wrapperHashMatches': True, 'counts': r170['counts'], 'boundaryStateUnchanged': True, 'measuredCommit': r170['code']['gitSha']}
wrapper244 = load('docs/evidence/feature-store-244/checkpoint-3-qualification.json')
replays = []
for expected in wrapper244['receipts']:
    path = Path('docs/evidence/feature-store-244', expected['file'])
    assert digest(path.read_bytes()) == expected['sha256']
    replay = load(path)
    assert replay['status'] == 'replay-verified'
    assert replay['boundaries']['initial']['stateSha256'] == replay['boundaries']['final']['stateSha256']
    assert sum(row['count'] for row in replay['normalized']['normalizedParity']) == 103468
    assert len(replay['derived']['derivedParity']) == 20
    replays.append(replay)
assert replays[0]['normalized']['normalizedParity'] == replays[1]['normalized']['normalizedParity']
assert replays[0]['derived']['derivedParity'] == replays[1]['derived']['derivedParity']
result['replay244'] = {'wrapperHashesMatch': True, 'runs': 2, 'normalizedRows': 103468, 'derivedContexts': 20, 'parityRecordsEqualAcrossRuns': True, 'boundaryStatesUnchanged': True, 'measuredCommit': replays[0]['code']['gitSha']}
result['allPass'] = True
(out / 'offline-details.json').write_text(json.dumps(result, indent=2) + '\n')

node = '/Users/vernonneilly/.nvm/versions/node/v24.18.1/bin/node'
command = [node, 'node_modules/vitest/vitest.mjs', 'run', '--config', 'vitest.node.config.ts', '--exclude', 'codex-briefs/**', 'services/pipeline/tests/feature-store/replay-identity.test.ts', 'services/pipeline/tests/feature-store/replay-normalized.test.ts']
env = dict(os.environ)
env.pop('R2_LIVE_CONTRACT', None)
env['PATH'] = str(Path(node).parent) + ':' + env['PATH']
run = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(out / 'focused-integration-tests.log').write_bytes(run.stdout)
check = {'name': 'focused-integration-tests', 'command': command, 'exitCode': run.returncode, 'sha256': digest(run.stdout), 'byteSize': len(run.stdout), 'path': str((out / 'focused-integration-tests.log').relative_to(root)), 'scope': 'Verified-wire reuse/release/registration and repository identity guard; no DB or hosted access'}
(out / 'focused-integration-tests.json').write_text(json.dumps(check, indent=2) + '\n')
print(json.dumps({'archiveRecords': len(archived), 'scrubWrapper': 'pass', 'replayWrappers': 'pass', 'calibrationReceiptReferences': 'pass', 'focusedTestsExitCode': run.returncode}))
if run.returncode:
    print(run.stdout.decode())
    raise SystemExit(run.returncode)
