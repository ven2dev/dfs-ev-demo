import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";

// HEAD metadata only: never request GET, read a response body, or use a DB.
assert.match(process.version, /^v24\./);
const path = "docs/evidence/feature-store-138/step-3-source-manifest.json";
const bytes = await readFile(path);
const manifest = JSON.parse(bytes.toString());
assert.equal(manifest.assets.length, 16);
const startedAt = new Date().toISOString();
const stamp = startedAt.replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
const output = "codex-briefs/169-size-observation-" + stamp + ".json";
const results = [];
const checked = value => {
  const url = new URL(value);
  assert(url.protocol === "https:" && !url.port && !url.username && !url.password &&
    ["github.com", "release-assets.githubusercontent.com"].includes(url.hostname), "metadata-url-refused");
  return url;
};
for (const { asset } of manifest.assets) {
  const entry = { name: asset.name, url: asset.url, pinnedBytes: asset.wire_bytes, pinnedSha256: asset.sha256,
    startedAt: new Date().toISOString(), requests: [], advertisedBytes: null, result: "unverified" };
  results.push(entry);
  try {
    let url = checked(asset.url);
    const signal = AbortSignal.timeout(20_000);
    for (let redirect = 0; redirect <= 3; redirect++) {
      const response = await fetch(url, { method: "HEAD", redirect: "manual", signal, headers: {
        "Accept-Encoding": "identity", "User-Agent": "dfs-ev-demo-feature-store-spike", Accept: "application/octet-stream",
      } });
      const length = response.headers.get("content-length");
      const encoding = response.headers.get("content-encoding");
      entry.requests.push({ method: "HEAD", host: url.hostname, status: response.status, contentLength: length,
        contentEncoding: encoding, observedAt: new Date().toISOString(), responseBodyPresent: response.body !== null });
      // HEAD has no body by protocol; cancel any unexpected exposed stream.
      await response.body?.cancel();
      if ([301, 302, 303, 307, 308].includes(response.status)) {
        const location = response.headers.get("location");
        assert(location && redirect < 3, "metadata-redirect-refused");
        url = checked(new URL(location, url).href);
        continue;
      }
      assert.equal(response.status, 200, "metadata-http-refused");
      assert(!encoding || encoding === "identity", "metadata-content-encoding-refused");
      assert(length !== null && /^\d+$/.test(length) && Number.isSafeInteger(Number(length)), "metadata-size-unavailable");
      entry.advertisedBytes = Number(length);
      entry.differenceBytes = entry.advertisedBytes - entry.pinnedBytes;
      entry.result = entry.differenceBytes === 0 ? "same-advertised-size-hash-unverified" : "advertised-size-drift";
      break;
    }
  } catch (error) { entry.error = { message: String(error), code: error.cause?.code ?? error.code ?? null }; }
  entry.finishedAt = new Date().toISOString();
  console.log(JSON.stringify({ name: entry.name, pinnedBytes: entry.pinnedBytes, advertisedBytes: entry.advertisedBytes,
    result: entry.result, error: entry.error }));
}
const record = { issue: 169, kind: "head-only-pinned-url-size-observation", runtime: process.version, startedAt,
  finishedAt: new Date().toISOString(), sourceManifest: path, sourceManifestSha256: createHash("sha256").update(bytes).digest("hex"),
  scriptSha256: createHash("sha256").update(await readFile("codex-briefs/169-size-check.mjs")).digest("hex"),
  method: "HEAD", getRequests: 0, responseBodyBytesRead: 0, databaseUsed: false, qualificationAttempt: false,
  limitation: "Equal advertised size does not establish equal bytes or SHA-256. This observation does not refresh any pin.",
  results, counts: { checked: results.length, sizeDrift: results.filter(r => r.result === "advertised-size-drift").length,
    sameAdvertisedSize: results.filter(r => r.result === "same-advertised-size-hash-unverified").length,
    unverified: results.filter(r => r.result === "unverified").length } };
await writeFile(output, JSON.stringify(record, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ observation: output, counts: record.counts }));
