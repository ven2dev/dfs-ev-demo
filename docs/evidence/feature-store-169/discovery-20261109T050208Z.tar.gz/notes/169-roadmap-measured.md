# #169 measured roadmap — approval checkpoint

Producer base: 9ef323eb98cf89b260a1135d7d91bd70a39ac3f1, including #251 / PR #252 and #244 / PR #253. Branch: feature/dfsEV-169-producer-capacity-matrices. The tracked tree is clean; no #169 implementation commit or push. This local review version consolidates the approved scope and measured spike. Earlier issue comments and receipts remain unchanged.

## Design basis

**Pattern:** repeatable producer capacity qualification from pinned inputs, using the existing #138/#241 workload and worker recipes, #251 transfer support, and the established typed-record/pure-auditor pattern. Runner and auditor share the verdict calculation. No new benchmark framework, producer algorithm, authorization or SQL is planned.

**Paired ingestion:** observe the original GitHub URL with observeLiveDownload; ingest exact original bytes through openTransferFixture and the real downloader/producer. Each attempt keeps its own two legs. The conservative sum counts complete live transfer/hash plus pinned validation, loopback transfer, ObjectStore publication, normalization, ANALYZE and COMMIT. Cold also counts process/import/connect once. Retain additional observation/IPC overhead rather than subtracting it. This does not claim GitHub still serves the original pin.

**Alternatives:** repinning changes the approved fixture and requires new parity/coverage proof. Cached-download-only measurement omits production network cost; a no-op omits recomputation/publication. A copied downloader or separate verdict formulas risk drift. Self-hosting originals measures Cloudflare instead of production's GitHub path; the existing edgetrace-fs-test bucket is also synthetic-only. The bucket's existence is not in question.

**Targets:** every representative ingestion pair <=42 s, each leg within its 60 s deadline, exactly 12 producer SQL, one bulk normalized insert and no per-example calls. Every full 2025 feature trial <=84 s under 120 s, exactly 8 producer SQL, one materialization and no per-example queries or source-byte reads during recomputation. At least three cold and three warm trials per workload; every individual attempt passes. No pooled/percentile substitution or target relaxation. Dataset <=21 s qualification is separate.

**Requirement reasons:** input and code/blob pins prevent silent drift. Full live transfers prevent omitted network cost. ObjectStore keeps artifact access within the storage boundary. Explicit per-trial loopback evidence prevents saved GitHub provenance being mistaken for measured transport. Restricted production hosts prevent a benchmark host bypass reaching production. Fixed statement counts prevent row-by-row work. Fresh databases and destinations prevent no-ops qualifying. Keeping every started attempt and stopping on failure prevents survivor bias and replacement samples. Hash/size verification before deletion proves which bytes were used without committing raw downloads. Clock preflight detects an unsuitable environment without falsifying knowledge timestamps.

**Assumptions:** trusted local producer/database owner, private ObjectStore, restricted LOGIN, Node 24 native stripping and historical reconstruction. The 16 originals total 246,304,787 wire bytes, seasons 2021–2025. The 2025 producer has 1,948 candidate outputs and 31,168 lineage links. The historical 2,504-row dataset hash a4de10aaefec7ec33d1c913fc255ee3527108f9d1f53e22afb79b82a9f9c607d is a different fixture identity; this spike did not rebuild that dataset. Retain historical-availability-unverified. Local timings prove neither hosted capacity nor population completeness. Host/Docker/DNS/CDN caches remain uncontrolled.

## Measured spike results

**Verdict: spike pass, not final qualification.** Thirty unique passing attempts: 20 from paired-20261109T034004Z retained byte for byte, plus ten new attempts in resumed-20261109T034805Z. The resume ran six feature trials first, then participation blocks 2–3. No completed attempt was rerun or replaced.

| Workload | Cold / warm | Full measured range | SQL each |
| --- | --- | --- | --- |
| games.csv.gz | 3 / 3 | 0.820–1.548 s | 12 |
| stats_player_week_2025.csv.gz | 3 / 3 | 1.352–1.813 s | 12 |
| roster_weekly_2021.csv | 3 / 3 | 2.357–2.791 s | 12 |
| pbp_participation_2023.csv | 3 / 3 | 6.524–11.257 s | 12 |
| Features 2025 | 3 / 3 | 6.595–10.427 s | 8 |

| Feature trial | Full measured time | Peak tmpfs | Growth from block admission |
| --- | ---: | ---: | ---: |
| Cold 1 | 6.643 s | 310.086 MiB | 263.891 MiB |
| Warm 1 | 10.427 s | 311.305 MiB | 265.109 MiB |
| Cold 2 | 6.618 s | 310.117 MiB | 263.922 MiB |
| Warm 2 | 10.325 s | 309.906 MiB | 263.711 MiB |
| Cold 3 | 6.595 s | 308.961 MiB | 262.766 MiB |
| Warm 3 | 10.396 s | 309.891 MiB | 263.695 MiB |

All six feature trials met <=84 s under 120 s and exactly eight SQL. Each prepared all 16 originals through ObjectStore and final ingestion outside feature timing, produced 1,948 outputs and 31,168 lineage links, and retained all historical-availability flags. All six output hashes match: 315806925202863e226a4a93f5d477b8a6d32cd38c5a4977a1d98f889bf242a9. Warm was slower than cold here; no causal explanation or relative performance claim is inferred from this absolute gate.

Peak feature growth was 277,987,328 bytes / 265.109 MiB against the unchanged 489,472,000-byte / 466.797 MiB basis. Peak mount use was 326,426,624 bytes / 311.305 MiB on the verified 2 GiB mount. The spike indicates no need for disk requalification. Ingestion peak was 73.508 MiB. These are sampled peaks, not continuous exact maxima.

All 24 ingestion pairs used exactly 12 SQL. Every receipt distinguishes its exact loopback origin/path and original hash/size from the GitHub URL intentionally retained in database provenance. Each has a request-time ObjectStore source read. Live schedule drift was observation; other measured live files matched their original pins. No protocol/transport/timeout failure occurred in the 30 successful samples. Transfer observations showed idle backends, no open transactions/locks and zero producer SQL during download. Publication's expected locks are outside that finding. Destinations were hash/size checked, deleted through ObjectStore and verified absent; originals remained intact and live observer bodies were not persisted.

Independent disposable verification checked all 30 populations/IDs, pair times, 12/8 work, loopback/cleanup evidence, feature parity, disk calculations and 25 source SHA-256 hashes and git blob IDs against HEAD. The inventory includes 241_job_visibility.sql, the other loaded proposal SQL and #251 transfer modules. Producer sources remained unchanged.

The resume's largest absolute clock estimate was 1.563 ms. Before each block, ten host/database observations record signed database-minus-host midpoint estimates, round-trip bounds, the 1 ms host-clock quantization interval and a 250 ms tolerance. Any measured absolute estimate above 250 ms refuses that block as a test-environment failure; exactly +/-250 ms passes. Every new sample carries its block's preflight. This is outside capacity timing. No timestamp adjustments, sleeping or constraint changes. Thirteen offline controls cover equality, just-over boundaries, old 30 s skew, malformed observations and sample population/order.

Historical stops remain: mutable schedule size refusal; the genuine 23514 captured_at <= ingested_at failure with approximately 30 s skew; and the 20-sample run stopped by the withdrawn extra clock-overlap gate. None is rewritten or counted as successful. The owner approved finishing only unstarted IDs in a separate receipt.

Evidence (local, ignored; not posted):

- codex-briefs/169-spike/paired-20261109T034004Z/report.json — 20 retained samples, SHA-256 fdcc09a24ffb0b94cdfbcd7d05b28b8cc674ba20df82bb5a124931d82d3d3900.
- codex-briefs/169-spike/resumed-20261109T034805Z/report.json — ten new samples, SHA-256 23cbf4bf3acb623344b70f3ee4f722b4d080126758b323140ee333f8aa123a0a. References the preceding receipt by hash/size. Exact disposable sources were appended and hash-verified.
- codex-briefs/169-spike-combined-verification-20261109T034805Z.json — combined verification and exact per-feature time/disk records.
- codex-briefs/169-resume-controls-20261109T034753Z.json — deterministic environment and resume controls.

Lane-3 teardown and container absence were verified at 2026-11-09T03:51:41.888Z. ALT received the all-clear. That quiet window is closed.

## Implementation steps and checkpoints

### Step 1 — runner/worker and attempt contract

Adapt existing #138/#241 recipes, consuming #251's helpers; keep the runner-facing interface narrow and avoid a generic framework. Add typed attempts, one shared verdict calculation, explicit new destinations, and append-only started/terminal records. Parent monotonic time is authoritative. Count cold process/import/connect once and disclose warm setup. Enforce per-leg deadlines, paired sum and feature deadline; retain censored failures, prevent late completion reviving expired work and stop without retry/replacement. Pin final runner/worker, clocks/verdict/auditor, loaded SQL including 241_job_visibility.sql, manifests, dependencies and lane controls by source hash and committed blob ID. Report diff and focused behavior/work checks, then stop for commit approval.

Owner-approved diagnostic addition to Steps 1 and 3: for every feature trial retain each SQL statement's elapsed time, pg_stat_checkpointer and pg_stat_wal snapshots before/after, sampled autovacuum activity and table counters. Observer statements are separate from the eight producer statements. These observations address the spike's approximately 57% warm slowdown without adding a gate, changing a target or claiming a cause unsupported by the data.

### Step 2 — deterministic auditor and refusal proofs

Reuse the existing TypeScript hash-first evidence and deterministic bundle pattern. Recompute populations, pair arithmetic, refusal/deadline outcomes, exact 12/8 work, loopback provenance, cleanup, resets, clock preflight and source identities. Reject missing/duplicate/replacement attempts, unknown formats and tampering. Test exact/over-target boundaries, failed live/protocol/timeout legs, wrong pins, production loopback refusal, incomplete cleanup and the +/-250 ms environment boundary. CI uses controlled clocks/workers and deterministic work, without machine-speed assertions. Node 24 commands exclude codex-briefs/**. Focused DB checks use standard-tier lane-3, a CLI-derived URL, preflight and verified teardown. Report diff/tests, then stop for commit approval.

### Step 3 — final committed-source qualification and durable evidence

After runner/auditor source commits are approved, obtain a separate fresh owner-confirmed ALT quiet window. Run all 30 final attempts anew on large-tier lane-3; do not count the disposable spike as final qualification. Four representatives each get 3 cold/3 warm live+pinned pairs, plus 3 cold/3 warm full-season feature trials on the full original input graph. Preserve all inputs, targets, counts and resource settings; every failure is retained and stops the run. Clock offset above tolerance stops the block as an environment refusal.

Record one complete lane down/up per cold/warm block, container/postmaster identity and block mapping. Each trial gets a fresh scratch database and empty destination. Preparation warms pages; tmpfs/server restart resets shared buffers/data without establishing cold physical caches. Record preflight >=608 MiB free, actual mount, sampled peak, WAL/temp/database sizes and growth against the 466.8 MiB basis. Use only lane-3 / port 54349, DB_TEST_LANE=lane-3 and DB_TEST_TIER=large through teardown. No other large lane or heavy work during timing. Verify container absence and give ALT the all-clear.

Publish detailed records through the local ObjectStore and add new compact receipts and deterministic compressed records under docs/evidence/feature-store-169/. Retain discovery stops/limitations, never overwrite historical evidence, and keep raw source downloads out of git. Update the feature doc, evidence README, PR draft and review handoff. Auditor checks use the pinned final records. Report qualification/evidence diff and checks, then stop for commit approval. Review and fresh one-time consent precede pushing; no attribution lines, hosted writes, Production commands or frozen-migration edits.

## Measured re-estimate

Total #169 planning estimate: **4.75–5 h**, excluding #251's separate work and owner/quiet-window waiting. Completed intake/discovery/disposable validation is allocated 1.75–2 h; remaining runner/worker 1.25 h, deterministic auditor/tests 1 h, final qualification/evidence/docs 0.75 h. This is a planning estimate, not a retrospective stopwatch measurement. Measured work now fits the existing disk tier and all targets without producer optimization. The ten-attempt resume took about 3.6 minutes including repeated full input preparation and lane resets.

No further split proposed at this estimate. If new work would take the total above five hours, stop and propose a split before expanding scope. The owner approved this measured roadmap and Step 1, including the diagnostic addition. Every step stops for commit approval. Final committed-source timings require their own quiet window.
