# #169 disposable spike — stopped on pinned-source refusal

Branch `feature/dfsEV-169-producer-capacity-matrices`, unchanged HEAD `4ce685ae83980241ddd6759e3ff1a6dcd5f932b6`. Tracked tree unchanged; no commit or push.

Approved roadmap comment: https://github.com/ven2dev/dfs-ev-demo/issues/169#issuecomment-6723711776

Run record: `169-spike/run-20261108T160326Z/report.json`; append-only lifecycle, started-attempt and sampled-observation journals are beside it. The probe was disposable, with no producer edits.

## Stop

The first representative, `games.csv.gz`, was refused with `ingest-wire-metadata-refused`. The pinned manifest says 515,250 wire bytes. The response from `release-assets.githubusercontent.com` advertised Content-Length 516,514 with no Content-Encoding, after a 302 from `github.com`. The downloader cancelled that response body before normalization/publication. The current response's full-body SHA-256 was not measured; this is a metadata-versus-pin conflict, not a demonstrated digest mismatch.

This is retained as a censored incomplete network attempt, never retried or replaced. Producer SQL count was zero, so it does not qualify the required 12-statement success path. The remaining three ingestion representatives and full-season feature pass were not started. No timing verdict is claimed.

## Locks, cleanup and disk

Four download-phase observations all saw producer PID 123 idle, xact_start/backend_xid/backend_xmin null, zero producer SQL calls and no pg_locks entries. No transaction or row lock spanning the observed request was found. This does not qualify the lock behavior of a completed body transfer or the unrun representatives. Row locks are not all enumerated by pg_locks; the additional no-transaction/zero-SQL observations matter.

Actual large-tier mount: 2,147,483,648 bytes. Settings remained max_wal_size=1GB, min_wal_size=80MB, fsync/synchronous_commit/full_page_writes on. Admission used 48,439,296 bytes; sampled peak 72,163,328 bytes (68.8203125 MiB), growth 23,724,032 bytes (22.625 MiB). Nine disk observations; peak WAL 33,554,432 bytes; no temporary files observed. These are partial refused-attempt measurements, not full-workload disk qualification. Both schema and workload preflight passed with the unchanged 608 MiB admission requirement.

The trial's ObjectStore destination contained no raw objects; cleanup confirmed it remained empty. Original pinned storage was left intact. No downloaded raw bytes were retained or added to Git.

Lane-3 was recreated for this isolated pass. PostgreSQL started at 2026-11-08 16:03:28.878616+00; teardown completed 2026-11-08T16:03:32.003Z, container absence checked. The quiet window ended at 2026-11-08T16:03:32.005Z and ALT was released. Final timings need a separate confirmed quiet window. Final matrix server resets remain once per cold/warm block, with no claim of physically cold caches.

## Estimate and owner decision

Conditional revised estimate: 4.5–5 h for the approved scope if an approved download location serving the exact pinned bytes is available. Full-workload disk/count estimates remain unproven because qualification stopped early. No larger scope or split is yet justified by measurements.

Do not silently repin the mutable release URL or substitute cached originals for real-download qualification. Next owner decision: provide/approve a real-download location for the exact pinned schedule, or approve a fixture-version change with its required parity work and a new estimate. A fixture refresh is outside this estimate and could require a split if total work exceeds five hours. No further spike attempt before that decision and a fresh quiet window.
