# #169 readiness while ALT #250 owns the large window

Branch remains feature/dfsEV-169-producer-capacity-matrices at 9ef323eb98cf89b260a1135d7d91bd70a39ac3f1. No tracked changes, commits or pushes. The capacity spike is still stopped; final qualification has not run.

## Clock diagnostic

Used standard-tier lane-3 only, with DB_TEST_LANE=lane-3, Node 24.18.1, a CLI-derived test URL, lane lease, preflight and completed teardown. Ten SELECT-only clock comparisons ran against the primary disposable DB. No migration/schema or workload preparation, network download, timing trial, Docker restart or clock-setting change. ALT's lane-2 was not accessed.

The previous approximately 30-second host/database discrepancy was not present. The intersection of the ten database-minus-host offset intervals was [-0.68310546875, -0.070068359375] ms, with millisecond host clock granularity disclosed. Eight observations included zero within their round-trip bounds; two detected small negative offsets. This is evidence of submillisecond residual skew, not exact clock equality and not capacity qualification. No new clock acceptance threshold or timestamp rewrite is introduced.

Report: codex-briefs/169-clock-20261109T032410Z/report.json. Lane-3 container absence was verified after down; ALT retains its active large-tier window.

## Offline readiness

Read all 16 original objects through ObjectStore and checked each SHA-256 and byte size against the original manifest. All match, totalling 246,304,787 bytes. No raw writes, live downloads or database access in this validation. Seven diagnostic controls passed, including 30-second offsets in either direction, wall-clock reversal and millisecond rounding. Evidence: codex-briefs/169-offline-readiness-20261109T032542Z.json.

The stopped attempt's three probe sources were appended to its evidence directory and verified against the three original recorded source hashes before revising the disposable probe. The stopped report and sample remain unchanged.

The revised disposable probe captures clock observations on each fresh server and after pinned transfer/failure, retains capturedAt and structured database constraint details, and separately marks the actual pinned download versus validation/publication. Its lock finding therefore concerns transfer time rather than ordinary publication locks. These are diagnostic changes in ignored disposable files; no producer, SQL, pins, targets, budgets or permanent runner changes. All three disposable probe files parse under Node 24.

## Next checkpoint

A fresh owner-confirmed quiet window with ALT lane-2 down is still required before large-tier lane-3 or the 30-trial spike. The next run retains all attempts, records clocks without clamping them, uses one restart per cold/warm block and stops on the first failure. Any substantial skew observed before dispatch is returned for an environment decision, not silently corrected. Return completed spike measurements and the measured estimate before permanent implementation; final committed-source qualification gets a separate quiet window. No Docker-wide recovery is performed while ALT owns lane-2.
