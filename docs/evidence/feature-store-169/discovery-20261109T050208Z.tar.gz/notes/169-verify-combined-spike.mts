import assert from "node:assert/strict";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { readFile, writeFile } from "node:fs/promises";
import { sha256 } from "../services/pipeline/src/featureStore/objectStore.ts";
import { summarizeClockPreflight } from "./169-clock-observation.mts";

assert.match(process.version, /^v24\./);
const exec = promisify(execFile);
const retainedPath = "codex-briefs/169-spike/paired-20261109T034004Z/report.json";
const resumedPath = "codex-briefs/169-spike/resumed-20261109T034805Z/report.json";
const retainedBytes = await readFile(retainedPath), resumedBytes = await readFile(resumedPath);
const retained = JSON.parse(retainedBytes.toString()), resumed = JSON.parse(resumedBytes.toString());
assert.equal(sha256(retainedBytes), resumed.resumes.sha256); assert.equal(retainedBytes.length, resumed.resumes.byteSize);
assert.equal(resumed.retainedRecordUnchanged, true); assert.equal(resumed.verdict, "pass");
assert.equal(retained.samples.length, 20); assert.equal(resumed.samples.length, 10);
assert.deepEqual(retained.sourceHashes, resumed.sourceHashes); assert.deepEqual(retained.sourceBlobIds, resumed.sourceBlobIds);
assert.equal(retained.base, resumed.base); assert.equal(resumed.base, (await exec("git", ["rev-parse", "HEAD"])).stdout.trim());
for (const [path, hash] of Object.entries(resumed.sourceHashes)) {
  assert.equal(sha256(await readFile(path)), hash, path);
  assert.equal((await exec("git", ["rev-parse", "HEAD:" + path])).stdout.trim(), resumed.sourceBlobIds[path], path);
}
const all = [...retained.samples, ...resumed.samples];
const ids = all.map((sample: any) => sample.id); assert.equal(new Set(ids).size, 30);
const names = ["games.csv.gz", "stats_player_week_2025.csv.gz", "roster_weekly_2021.csv", "pbp_participation_2023.csv", "features-2025"];
const expectedIds = names.flatMap(name => [1, 2, 3].flatMap(block => ["cold", "warm"].map(mode => name + ":" + block + ":" + mode)));
assert.deepEqual([...ids].sort(), [...expectedIds].sort());
assert.deepEqual(resumed.samples.slice(0, 6).map((sample: any) => sample.name), Array(6).fill("features-2025"));
for (const sample of all) {
  const feature = sample.name === "features-2025";
  assert.equal(sample.verdict, "pass"); assert.equal(sample.error, undefined);
  assert.equal(sample.sql.length, feature ? 8 : 12);
  assert(Number.isFinite(sample.measuredMs) && sample.measuredMs > 0 && sample.measuredMs <= (feature ? 84_000 : 42_000));
  assert.equal(sample.cleanup.completed, true);
  if (feature) {
    assert.equal(sample.value.result.status, "succeeded"); assert.equal(sample.inputs.length, 16);
    assert.equal(sample.value.result.work.perExampleQueries, 0); assert.equal(sample.value.result.work.materializations, 1);
    assert.equal(sample.value.result.work.sourceByteReads, 0);
    assert.deepEqual(sample.output, { rows: 1948, missing_flag: 0, lineage_links: 31168 });
    assert(sample.peakGrowthBytes <= 489472000);
  } else {
    assert.equal(sample.value.result.status, "ingested"); assert.equal(sample.value.live.status, "completed");
    assert(sample.value.live.elapsedMs <= 60_000 && sample.value.pinnedMs <= 60_000);
    assert(Math.abs(sample.legSumMs - sample.value.live.elapsedMs - sample.value.pinnedMs) < 1e-6);
    assert(sample.measuredMs >= sample.legSumMs);
    assert.equal(sample.pinnedTransport.kind, "test-only-loopback"); assert.equal(sample.pinnedTransport.explicitSetting, true);
    assert.equal(new URL(sample.pinnedTransport.origin).hostname, "127.0.0.1");
    assert.equal(sample.pinnedTransport.pathname, "/fixture/0"); assert.equal(sample.pinnedTransport.sourceReads.length, 1);
    assert.equal(sample.databaseProvenance.url, sample.asset.url);
    assert.equal(sample.value.result.wireSha256, sample.asset.sha256); assert.equal(sample.value.result.wireBytes, sample.asset.wire_bytes);
    assert.equal(sample.lockFinding.openTransactionOrRowLock, false);
    assert.equal(sample.producerSqlAtDownloadStart, 0); assert.equal(sample.producerSqlAtDownloadEnd, 0);
  }
}
const features = all.filter((sample: any) => sample.name === "features-2025");
assert.equal(new Set(features.map((sample: any) => sample.outputContentSha256)).size, 1);
for (const block of resumed.blocks) {
  assert.deepEqual(block.clockPreflight, summarizeClockPreflight(block.clockObservations)); assert.equal(block.clockPreflight.pass, true);
  assert.equal(block.teardownComplete, true); assert.equal(block.peakUsedBytes, Math.max(...block.disk.map((row: any) => row.usedBytes)));
  assert.equal(block.peakGrowthBytes, block.peakUsedBytes - block.admission.usedBytes);
  assert(block.peakGrowthBytes <= 489472000);
  assert(block.disk.every((row: any) => row.capacityBytes === 2 * 1024 ** 3));
  for (const sample of resumed.samples.filter((sample: any) => sample.name === block.name && sample.blockNumber === block.blockNumber))
    assert.deepEqual(sample.clockPreflight, block.clockPreflight);
}
assert.equal(resumed.finalContainerAbsence, true); assert.equal(resumed.sourceUnchanged, true);
const groups = names.map(name => {
  const selected = all.filter((sample: any) => sample.name === name);
  return { name, cold: selected.filter((sample: any) => sample.mode === "cold").length,
    warm: selected.filter((sample: any) => sample.mode === "warm").length,
    minimumMs: Math.min(...selected.map((sample: any) => sample.measuredMs)),
    maximumMs: Math.max(...selected.map((sample: any) => sample.measuredMs)), sql: name === "features-2025" ? 8 : 12 };
});
const result = { issue: 169, kind: "combined-disposable-spike-verification", recordedAt: new Date().toISOString(), runtime: process.version,
  records: [{ path: retainedPath, sha256: sha256(retainedBytes), samples: 20 }, { path: resumedPath, sha256: sha256(resumedBytes), samples: 10 }],
  committedProducerBase: resumed.base, sourceFilesVerified: Object.keys(resumed.sourceHashes).length,
  groups, uniqueSamples: 30, featureOutputContentSha256: features[0].outputContentSha256,
  featureTrials: features.map((sample: any) => ({ id: sample.id, measuredMs: sample.measuredMs, sql: sample.sql.length,
    peakUsedBytes: sample.peakUsedBytes, peakGrowthBytes: sample.peakGrowthBytes, growthBudgetBytes: 489472000 })),
  maximumFeaturePeakUsedBytes: Math.max(...features.map((sample: any) => sample.peakUsedBytes)),
  maximumFeatureGrowthBytes: Math.max(...features.map((sample: any) => sample.peakGrowthBytes)),
  maximumNewClockAbsoluteOffsetMs: Math.max(...resumed.blocks.map((block: any) => block.clockPreflight.maximumAbsoluteOffsetMs)),
  historicalStopsRetained: true, sourceUnchanged: true, teardownComplete: true, windowEndedAt: resumed.windowEndedAt,
  verdict: "spike-pass-not-final-qualification" };
await writeFile("codex-briefs/169-spike-combined-verification-20261109T034805Z.json", JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(result, null, 2));
