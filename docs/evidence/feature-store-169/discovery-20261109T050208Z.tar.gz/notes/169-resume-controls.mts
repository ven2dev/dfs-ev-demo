import assert from "node:assert/strict";
import { readFile, writeFile } from "node:fs/promises";
import { summarizeClockPreflight } from "./169-clock-observation.mts";
import { sha256 } from "../services/pipeline/src/featureStore/objectStore.ts";

assert.match(process.version, /^v24\./);
const observations = (offset: number) => Array.from({ length: 10 }, () => ({
  offsetLowerMs: offset - .5, offsetUpperMs: offset + .5, roundTripMs: 1, hostWallMovedBackward: false,
}));
const controls = [];
for (const offset of [0, -1.3, 1.3, -250, 250]) {
  assert.equal(summarizeClockPreflight(observations(offset)).pass, true);
  controls.push({ offsetMs: offset, accepted: true });
}
for (const offset of [-250.001, 250.001, -30_000, 30_000]) {
  assert.equal(summarizeClockPreflight(observations(offset)).pass, false);
  controls.push({ offsetMs: offset, accepted: false });
}
const oneBad = observations(0); oneBad[9] = observations(251)[0];
assert.equal(summarizeClockPreflight(oneBad).pass, false);
const reversed = observations(0); reversed[0].hostWallMovedBackward = true;
assert.equal(summarizeClockPreflight(reversed).pass, false);
assert.throws(() => summarizeClockPreflight([]));
assert.throws(() => summarizeClockPreflight(observations(NaN)));
const path = "codex-briefs/169-spike/paired-20261109T034004Z/report.json";
const bytes = await readFile(path), prior = JSON.parse(bytes.toString());
assert.equal(prior.samples.length, 20); assert(prior.samples.every((sample: any) => sample.verdict === "pass"));
const plans = [{ name: "features-2025", blocks: [1, 2, 3] }, { name: "pbp_participation_2023.csv", blocks: [2, 3] }];
const newIds = plans.flatMap(({ name, blocks }) => blocks.flatMap(block => ["cold", "warm"].map(mode => name + ":" + block + ":" + mode)));
const priorIds = new Set(prior.samples.map((sample: any) => sample.id));
assert.equal(newIds.length, 10); assert(newIds.every(id => !priorIds.has(id)));
assert.equal(new Set([...priorIds, ...newIds]).size, 30);
assert(newIds.slice(0, 6).every(id => id.startsWith("features-2025:")));
const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
const output = "codex-briefs/169-resume-controls-" + stamp + ".json";
await writeFile(output, JSON.stringify({ issue: 169, kind: "offline-resume-controls", runtime: process.version,
  retainedRecord: { path, sha256: sha256(bytes), byteSize: bytes.length }, clockControls: controls,
  additionalControls: ["one-bad-observation", "host-wall-reversal", "empty-preflight", "nonfinite-preflight"],
  priorSamples: 20, newIds, combinedUniqueSamples: 30, databaseUsed: false, networkUsed: false, verdict: "pass" }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify({ output, clockControls: controls.length + 4, newIds, verdict: "pass" }));
