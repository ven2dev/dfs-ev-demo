import assert from "node:assert/strict";

// Diagnostic only. An offset interval comes from the host wall times around a
// DB clock query; the monotonic RTT bounds transfer time, not clock accuracy.
export const summarizeClockObservation = (hostBeforeMs: number, hostAfterMs: number, dbMs: number, roundTripMs: number) => {
  assert([hostBeforeMs, hostAfterMs, dbMs, roundTripMs].every(Number.isFinite));
  assert(roundTripMs >= 0);
  const offsetLowerMs = dbMs - (hostAfterMs + 1);
  const offsetUpperMs = dbMs - hostBeforeMs;
  return { offsetLowerMs, offsetUpperMs, roundTripMs,
    hostWallMovedBackward: hostAfterMs < hostBeforeMs,
    compatibleWithRoundTrip: hostAfterMs >= hostBeforeMs && offsetLowerMs <= 0 && offsetUpperMs >= 0,
    interpretation: "Database minus host offset interval; zero inside is consistent with alignment, not proof of exact clock equality. Integer wall times have millisecond rounding." };
};

export const summarizeClockPreflight = (observations: {
  offsetLowerMs: number; offsetUpperMs: number; roundTripMs: number; hostWallMovedBackward: boolean;
}[]) => {
  assert.equal(observations.length, 10, "clock-preflight-requires-ten-observations");
  for (const observation of observations) {
    assert([observation.offsetLowerMs, observation.offsetUpperMs, observation.roundTripMs].every(Number.isFinite));
    assert(observation.roundTripMs >= 0);
  }
  const offsetsMs = observations.map(row => (row.offsetLowerMs + row.offsetUpperMs) / 2);
  const maximumAbsoluteOffsetMs = Math.max(...offsetsMs.map(Math.abs));
  return { kind: "test-environment-clock-offset", toleranceMs: 250,
    estimator: "database minus host round-trip midpoint, including the 1 ms host wall-clock quantization interval",
    observationCount: observations.length, offsetsMs, maximumAbsoluteOffsetMs,
    offsetIntervalMs: { lower: Math.max(...observations.map(row => row.offsetLowerMs)),
      upper: Math.min(...observations.map(row => row.offsetUpperMs)) },
    pass: maximumAbsoluteOffsetMs <= 250 && observations.every(row => !row.hostWallMovedBackward),
    note: "Environment preflight only, outside capacity timing. No timestamp adjustment, waiting or SQL-constraint change." };
};

export const observeClock = async (client: { query: (sql: string) => Promise<{ rows: { database_at: string; database_ms: string }[] }> }) => {
  const monotonicBefore = performance.now(), hostBeforeMs = Date.now();
  const row = (await client.query(`WITH clock AS MATERIALIZED (SELECT clock_timestamp() AS now)
    SELECT now::text AS database_at, (extract(epoch FROM now) * 1000)::text AS database_ms FROM clock`)).rows[0];
  const hostAfterMs = Date.now(), roundTripMs = performance.now() - monotonicBefore;
  return { hostBeforeAt: new Date(hostBeforeMs).toISOString(), hostAfterAt: new Date(hostAfterMs).toISOString(),
    databaseAt: row.database_at, databaseMs: Number(row.database_ms),
    ...summarizeClockObservation(hostBeforeMs, hostAfterMs, Number(row.database_ms), roundTripMs) };
};
