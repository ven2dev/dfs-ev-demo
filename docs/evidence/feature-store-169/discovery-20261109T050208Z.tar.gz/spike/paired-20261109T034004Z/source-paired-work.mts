import assert from "node:assert/strict";
import { ingestSource } from "../../services/pipeline/src/featureStore/ingest.ts";
import { runDerivedJob } from "../../services/pipeline/src/featureStore/derived.ts";
import { observeLiveDownload } from "../../services/pipeline/scripts/feature-store/live-download.ts";
import { downloadPinnedWire } from "../../services/pipeline/src/featureStore/sourceTransfer.ts";

// Disposable shared worker recipe; final code will be written after spike review.
export const perform = async ({ client, store, asset, code, transport, notify, sql }: any) => {
  const measured = new Proxy(client, { get(target, property) {
    if (property !== "query") return Reflect.get(target, property, target);
    return (...args: any[]) => {
      sql.push({ text: typeof args[0] === "string" ? args[0] : args[0].text, at: new Date().toISOString() });
      return Reflect.apply(target.query, target, args);
    };
  } });
  if (!asset) {
    await notify("feature-start");
    const started = performance.now();
    const result = await runDerivedJob(measured, "features", { season: 2025, mode: "retrospective-reconstruction-v1" }, code);
    return { result, producerMs: performance.now() - started, processId: process.pid, sql };
  }
  await notify("live-download-before");
  const live = await observeLiveDownload(asset);
  await notify("live-download-after", { live });
  if (live.status !== "completed") throw new Error("live-download-failed:" + live.error.code);
  assert(live.elapsedMs <= 60_000, "live-download-deadline");
  assert(live.elapsedMs <= 42_000, "live-leg-alone-exceeds-pair-target");
  await notify("pinned-ingestion-before");
  const started = performance.now();
  let result;
  try {
    result = await ingestSource(measured, store, asset, code, { download: async (selected, signal, limits) => {
      assert.equal(selected.url, asset.url);
      await notify("pinned-download-before", { producerSqlAtDownloadStart: sql.length });
      // Same shared transport primitive used by openTransferFixture.download.
      // Serializable exact-origin mapping lets the fresh worker use the parent
      // fixture server without an IPC byte transfer or copied HTTP implementation.
      const downloaded = await downloadPinnedWire(transport.origin + transport.pathname, selected.wire_bytes, signal, limits!.wireBytes, fetch,
        { kind: "fixture", origin: transport.origin, pathname: transport.pathname });
      await notify("pinned-download-after", { pinnedCapturedAt: downloaded.capturedAt, hostAfterDownloadAt: new Date().toISOString(),
        producerSqlAtDownloadEnd: sql.length });
      await notify("pinned-validation-publication");
      return downloaded;
    } });
  } catch (error) {
    const pg = error as { message?: string; code?: string; schema?: string; table?: string; constraint?: string; detail?: string };
    await notify("pinned-ingestion-failed", { pinnedFailedMs: performance.now() - started,
      databaseError: { message: pg.message ?? String(error), code: pg.code ?? null, schema: pg.schema ?? null,
        table: pg.table ?? null, constraint: pg.constraint ?? null, detail: pg.detail ?? null } });
    throw error;
  }
  const pinnedMs = performance.now() - started;
  await notify("pinned-ingestion-after", { pinnedMs });
  return { result, live, pinnedMs, processId: process.pid, sql };
};
