import assert from "node:assert/strict";
import { execFile, fork } from "node:child_process";
import { promisify } from "node:util";
import { appendFile, mkdir, mkdtemp, readFile, realpath, rm, writeFile } from "node:fs/promises";
import { arch, cpus, platform, release, tmpdir, totalmem } from "node:os";
import { join, resolve } from "node:path";
import { Client } from "pg";
import { assertNoApplicationCredentials, getTestDatabaseLane, parseTestDatabaseUrl } from "@dfs-ev/db-tooling/test-support/target";
import { startDatabaseTestRun, DatabaseTestRunActiveError } from "@dfs-ev/db-tooling/test-support/lifecycle";
import { withFeatureStoreDatabase } from "../../services/pipeline/scripts/feature-store/harness.ts";
import { openTransferFixture } from "../../services/pipeline/scripts/feature-store/transfer-fixture.ts";
import { ingestSource } from "../../services/pipeline/src/featureStore/ingest.ts";
import { openLocalObjectStore } from "../../services/pipeline/src/featureStore/localObjectStore.ts";
import { sha256, type ObjectStore } from "../../services/pipeline/src/featureStore/objectStore.ts";
import type { SourceAsset } from "../../services/pipeline/src/featureStore/source.ts";
import { perform } from "./paired-work.mts";
import { observeClock } from "../169-clock-observation.mts";

assert.equal(process.env.DB_TEST_LANE, "lane-3"); assert.equal(process.env.DB_TEST_TIER, "large");
assert.match(process.version, /^v24\./); assertNoApplicationCredentials(process.env);
const exec = promisify(execFile);
const env = { ...process.env, DB_TEST_LANE: "lane-3", DB_TEST_TIER: "large" };
delete env.TEST_DATABASE_URL;
const selected = getTestDatabaseLane("lane-3");
const stamp = new Date().toISOString().replace(/[-:]/g, "").replace(/\.\d+Z$/, "Z");
const directory = resolve("codex-briefs/169-spike/paired-" + stamp);
await mkdir(directory, { mode: 0o700 });
const command = async (name: string, args: string[]) => (await exec(name, args,
  { env, cwd: process.cwd(), maxBuffer: 16 * 1024 * 1024 })).stdout.trim();
const cli = async (operation: string) => {
  let output = "", error = null;
  try { return output = await command(process.execPath, ["scripts/db/test-db.mjs", operation]); }
  catch (caught) { error = String(caught); throw caught; }
  finally { await appendFile(join(directory, "lifecycle.jsonl"), JSON.stringify({ at: new Date().toISOString(), operation, output, error }) + "\n"); }
};
env.TEST_DATABASE_URL = await cli("url"); process.env.TEST_DATABASE_URL = env.TEST_DATABASE_URL;
assert.equal(new URL(env.TEST_DATABASE_URL).port, "54349");
const manifestPath = "docs/evidence/feature-store-138/step-3-source-manifest.json";
const manifestBytes = await readFile(manifestPath);
const manifest = JSON.parse(manifestBytes.toString()) as { assets: { asset: SourceAsset }[] };
const previous = JSON.parse(await readFile("docs/evidence/feature-store-138/step-3-real-ingestion.json", "utf8"));
const originals = await openLocalObjectStore(await realpath(previous.storageRoot));
const names = ["games.csv.gz", "stats_player_week_2025.csv.gz", "roster_weekly_2021.csv", "pbp_participation_2023.csv", "features-2025"];
const inventory = ["packages/db/proposals/138_feature_store.sql", "packages/db/proposals/138_dataset_governance.sql",
  "packages/db/proposals/163_effective_rights.sql", "packages/db/proposals/241_job_visibility.sql",
  "services/pipeline/src/featureStore/ingest.ts", "services/pipeline/src/featureStore/source.ts", "services/pipeline/src/featureStore/sourceTransfer.ts",
  "services/pipeline/src/featureStore/normalize.ts", "services/pipeline/src/featureStore/verifiedWireAccess.ts", "services/pipeline/src/featureStore/jobs.ts",
  "services/pipeline/src/featureStore/derived.ts", "services/pipeline/src/featureStore/asOf.ts", "services/pipeline/src/featureStore/objectStore.ts",
  "services/pipeline/src/featureStore/localObjectStore.ts", "services/pipeline/scripts/feature-store/transfer-fixture.ts",
  "services/pipeline/scripts/feature-store/live-download.ts", "services/pipeline/scripts/feature-store/harness.ts",
  manifestPath, "package-lock.json", "compose.test.yml", "compose.feature-store-spike.yml",
  "packages/db/tooling/tests/target.mts", "packages/db/tooling/tests/startup.mts", "scripts/db/test-db.mjs", "scripts/db/db-test-disk.mjs"];
const sourceHashes = Object.fromEntries(await Promise.all(inventory.map(async path => [path, sha256(await readFile(path))])));
const sourceBlobIds = Object.fromEntries(await Promise.all(inventory.map(async path => [path, await command("git", ["hash-object", "--", path])])));
const base = await command("git", ["rev-parse", "HEAD"]);
const code = { gitSha: base, contentSha256: sha256(Buffer.from(JSON.stringify(sourceHashes))) };
const probeHashes = Object.fromEntries(await Promise.all(["paired-probe.mts", "paired-work.mts", "paired-cold.mts"].map(async name =>
  [name, sha256(await readFile("codex-briefs/169-spike/" + name))])));
probeHashes["169-clock-observation.mts"] = sha256(await readFile("codex-briefs/169-clock-observation.mts"));
const report: any = { issue: 169, kind: "disposable-paired-cold-warm-spike-not-final-qualification", base, code, sourceHashes, sourceBlobIds,
  probeHashes, runtime: process.version, startedAt: new Date().toISOString(), machine: { arch: arch(), cpus: cpus().length, platform: platform(), release: release(), totalMemoryBytes: totalmem() },
  lane: { selector: "lane-3", project: selected.project, port: 54349, tier: "large", mountBytes: 2 * 1024 ** 3 },
  quietWindow: "Owner confirmed lane-2 down and ALT heavy CPU/database work paused until Relay teardown/all-clear. Final qualification uses a separate window.",
  resetPolicy: "One complete lane-3 down/up per cold/warm block, three blocks per workload; scratch DB and destination are fresh per trial.",
  cacheLimitations: "No physical-cache-cold claim: tmpfs resets shared buffers/data, but preparation warms pages; host OS/Docker/DNS/CDN caches uncontrolled.",
  loader: "Node 24 native type stripping", sourceManifestSha256: sha256(manifestBytes), priorGrowthBasisBytes: 489472000,
  admissionFreeBytes: 608 * 1024 ** 2, blocks: [], samples: [], verdict: "running", windowEndedAt: null };
const save = () => writeFile(join(directory, "report.json"), JSON.stringify(report, null, 2) + "\n");
await save();
console.log(JSON.stringify({ directory, base, plannedSamples: 30 }));
const noOtherLarge = async () => assert.equal(await command("docker", ["ps", "--filter", "label=dev.dfs-ev.test-tier=large", "--format", "{{.Names}}"]), "", "another-large-lane-is-up");
const ourContainers = () => command("docker", ["ps", "-a", "--filter", "label=com.docker.compose.project=" + selected.project, "--format", "{{.ID}}"]);
assert.equal(await ourContainers(), "", "lane-3-not-idle");
await noOtherLarge();
let stop = false;
for (const name of names) {
  if (stop) break;
  for (let blockNumber = 1; blockNumber <= 3; blockNumber++) {
    if (stop) break;
    const block: any = { name, blockNumber, startedAt: new Date().toISOString(), disk: [], teardownComplete: false };
    report.blocks.push(block); await save();
    let control: Client | undefined, lease: Awaited<ReturnType<typeof startDatabaseTestRun>> | undefined;
    let timer: ReturnType<typeof setInterval> | undefined, pending = Promise.resolve(), busy = false, observerFailure: unknown, contention = false;
    let active: any = null, id = "", owned = false;
    const snapshot = async (boundary: string) => {
      const output = await command("docker", ["exec", id, "df", "-Pk", "/var/lib/postgresql"]);
      const f = output.split("\n").at(-1)!.trim().split(/\s+/);
      const data = (await control!.query(`SELECT clock_timestamp()::text AS at,
        (SELECT sum(size)::text FROM pg_ls_waldir()) AS wal_bytes,
        (SELECT coalesce(jsonb_agg(t),'[]') FROM pg_ls_tmpdir() t) AS temp_files,
        (SELECT jsonb_agg(jsonb_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database) AS databases,
        current_setting('max_wal_size') AS max_wal_size,current_setting('min_wal_size') AS min_wal_size,
        current_setting('fsync') AS fsync,current_setting('synchronous_commit') AS synchronous_commit,current_setting('full_page_writes') AS full_page_writes,
        (SELECT row_to_json(a) FROM (SELECT pid,state,xact_start::text,backend_xid::text,wait_event_type,wait_event
          FROM pg_stat_activity WHERE pid=$1) a) AS writer,
        (SELECT coalesce(jsonb_agg(l),'[]') FROM (SELECT locktype,mode,granted,relation::regclass::text,page,tuple FROM pg_locks WHERE pid=$1) l) AS locks`, [active?.writerPid ?? null])).rows[0];
      const row = { boundary, sampleId: active?.id ?? null, stage: active?.stage ?? null, capacityBytes: Number(f[1]) * 1024,
        usedBytes: Number(f[2]) * 1024, availableBytes: Number(f[3]) * 1024, ...data };
      assert.equal(row.capacityBytes, 2 * 1024 ** 3); block.disk.push(row);
      await appendFile(join(directory, "observations.jsonl"), JSON.stringify({ workload: name, block: blockNumber, ...row }) + "\n");
      if (active && row.writer && (row.stage.startsWith("live-download") || row.stage === "pinned-source-read" ||
          row.stage === "pinned-download-before" || row.stage === "pinned-download-after")) {
        active.lockObservations.push(row);
      }
      return row;
    };
    const boundary = async (label: string) => { await pending; return snapshot(label); };
    const checkObserver = () => { if (observerFailure) throw observerFailure; lease?.failureSignal.throwIfAborted(); };
    const cleanupRaw = async (store: ObjectStore, sample: any) => {
      sample.cleanup ??= { objects: [], completed: false };
      for (const object of await store.list("raw")) {
        const asset = manifest.assets.find(({ asset }) => "raw/" + asset.sha256 === object.key)?.asset;
        assert(asset, "unexpected-destination-object");
        const bytes = await store.get(object.key); const hash = sha256(bytes);
        assert.equal(hash, asset.sha256); assert.equal(bytes.length, asset.wire_bytes);
        await store.delete(object.key); assert.equal(await store.head(object.key), null);
        sample.cleanup.objects.push({ key: object.key, sha256: hash, wireBytes: bytes.length, deleted: true });
      }
      assert.equal((await store.list("raw")).length, 0); sample.cleanup.completed = true;
      await save();
    };
    try {
      await noOtherLarge();
      await cli("down"); block.downBeforeAt = new Date().toISOString();
      owned = true; await cli("up"); block.upAt = new Date().toISOString();
      id = await ourContainers(); assert(id && !id.includes("\n")); block.containerId = id;
      try { lease = await startDatabaseTestRun(env); }
      catch (error) { contention = error instanceof DatabaseTestRunActiveError; throw error; }
      control = new Client(parseTestDatabaseUrl(env.TEST_DATABASE_URL, "lane-3")); await control.connect();
      block.postmaster = (await control.query("SELECT pg_postmaster_start_time()::text AS started,version() AS version")).rows[0];
      block.clockObservations = [];
      for (let i = 0; i < 10; i++) block.clockObservations.push(await observeClock(control));
      await save();
      assert(block.clockObservations.some((row: any) => row.compatibleWithRoundTrip),
        "no-clock-observation-overlaps-host-roundtrip-stop-for-environment-review");
      block.admission = await boundary("admission");
      timer = setInterval(() => {
        if (busy) return; busy = true;
        pending = snapshot("sampled").then(() => {}).catch(error => { observerFailure = error; }).finally(() => { busy = false; });
      }, 250);
      for (const mode of ["cold", "warm"]) {
        const sample: any = { id: name + ":" + blockNumber + ":" + mode, name, blockNumber, mode,
          startedAt: new Date().toISOString(), stage: "schema-preparation", lockObservations: [], inputs: [], verdict: "running", sql: [] };
        active = sample; report.samples.push(sample); await save();
        await appendFile(join(directory, "started.jsonl"), JSON.stringify({ id: sample.id, at: sample.startedAt, phase: "schema-preparation" }) + "\n");
        let server: Awaited<ReturnType<typeof openTransferFixture>> | undefined, store: ObjectStore | undefined, destination: string | undefined;
        try {
          checkObserver(); sample.schemaPreflight = JSON.parse(await cli("preflight"));
          await withFeatureStoreDatabase(async db => {
            sample.database = (await db.admin.query("SELECT current_database() AS name")).rows[0].name;
            sample.writerPid = (await db.writer.query("SELECT pg_backend_pid() AS pid")).rows[0].pid;
            destination = await realpath(await mkdtemp(join(tmpdir(), "dfs169-paired-destination-")));
            store = await openLocalObjectStore(destination); assert.equal((await store.list("raw")).length, 0);
            const asset = name === "features-2025" ? null : manifest.assets.find(({ asset }) => asset.name === name)!.asset;
            if (asset) {
              sample.asset = asset;
              const key = "raw/" + asset.sha256;
              const pinned = await originals.get(key); assert.equal(sha256(pinned), asset.sha256); assert.equal(pinned.length, asset.wire_bytes);
              sample.pinnedTransport = { kind: "test-only-loopback", explicitSetting: true, originalSourceUrl: asset.url,
                objectKey: key, sha256: asset.sha256, wireBytes: asset.wire_bytes, sourceReads: [] };
              server = await openTransferFixture({ ...originals, get: async selectedKey => {
                assert.equal(selectedKey, key);
                const previousStage = sample.stage; sample.stage = "pinned-source-read";
                await boundary("pinned-request-before-source-read");
                const bytes = await originals.get(selectedKey);
                sample.pinnedTransport.sourceReads.push({ key: selectedKey, wireBytes: bytes.length, at: new Date().toISOString() });
                sample.stage = previousStage; return bytes;
              } }, [{ asset, key }], { testOnlyLoopback: true });
              sample.pinnedTransport.origin = server.origin; sample.pinnedTransport.pathname = "/fixture/0";
              sample.pinnedTransport.client = mode === "cold" ? "shared-downloadPinnedWire-exact-origin-capability" : "openTransferFixture-shared-transport";
            } else {
              for (const { asset: input } of manifest.assets) {
                sample.stage = "input-preparation:" + input.name;
                checkObserver(); await cli("preflight");
                const bytes = await originals.get("raw/" + input.sha256);
                assert.equal(sha256(bytes), input.sha256); assert.equal(bytes.length, input.wire_bytes);
                const before = db.queryCounts.writer;
                const loaded = await ingestSource(db.writer, store, input, code,
                  { download: async () => ({ bytes, capturedAt: new Date().toISOString(), requests: 0 }) });
                assert.equal(loaded.status, "ingested"); assert.equal(db.queryCounts.writer - before, 12);
                sample.inputs.push({ name: input.name, sha256: input.sha256, wireBytes: input.wire_bytes,
                  normalizedRows: loaded.status === "ingested" ? loaded.normalizedRows : null, sql: db.queryCounts.writer - before });
              }
              await boundary("inputs-complete");
            }
            sample.stage = "workload-preflight"; checkObserver(); sample.workPreflight = JSON.parse(await cli("preflight"));
            const config = mode === "cold" ? await db.createWriterConfig() : null;
            const notify = async (stage: string, data: any = {}) => {
              const { id: _messageId, kind: _kind, stage: _stage, ...observations } = data;
              sample.stage = stage; Object.assign(sample, observations);
              if (stage === "connected") sample.startupThroughConnectMs = performance.now() - sample.driverStarted;
              if (stage === "pinned-download-after" || stage === "pinned-ingestion-failed") {
                sample.clockAfterDownload = await observeClock(control!);
              }
              await boundary(stage); await save();
            };
            const start = performance.now(); sample.driverStarted = start;
            sample.timingStartedAt = new Date().toISOString();
            await appendFile(join(directory, "started.jsonl"), JSON.stringify({ id: sample.id, at: sample.timingStartedAt, phase: "measured-workload" }) + "\n");
            let value: any;
            if (mode === "cold") {
              value = await new Promise((resolveValue, reject) => {
                const child = fork(resolve("codex-briefs/169-spike/paired-cold.mts"), [], { env,
                  execPath: process.execPath, execArgv: ["--disable-warning=MODULE_TYPELESS_PACKAGE_JSON"], silent: true });
                sample.processId = child.pid;
                let result: any, failure: any, messages = Promise.resolve(), stderr = "", stdout = "";
                child.stderr!.on("data", bytes => { stderr += bytes; }); child.stdout!.on("data", bytes => { stdout += bytes; });
                const timeout = setTimeout(() => { failure = new Error("cold-worker-deadline"); child.kill("SIGKILL"); }, asset ? 120_000 : 120_000);
                child.on("message", (message: any) => {
                  messages = messages.then(async () => {
                    if (message.kind === "stage") { await notify(message.stage, message); child.send({ kind: "ack", id: message.id }); }
                    else if (message.kind === "result") { result = message.value; sample.responseBoundaryMs = performance.now() - start; }
                    else if (message.kind === "failure") { sample.sql = message.sql; failure = Object.assign(new Error(message.error), { code: message.code }); }
                  }).catch(error => { failure = error; child.kill("SIGKILL"); });
                });
                child.on("error", error => { failure = error; });
                child.on("close", async code => {
                  clearTimeout(timeout); await messages;
                  sample.workerOutput = { stdout, stderr, exitCode: code };
                  if (failure || code !== 0 || !result) reject(failure ?? new Error("cold-worker-incomplete")); else resolveValue(result);
                });
                child.send({ kind: "run", config, destination, asset, code, transport: sample.pinnedTransport });
              });
            } else {
              value = await perform({ client: db.writer, store, asset, code, transport: sample.pinnedTransport, notify, sql: sample.sql });
              sample.responseBoundaryMs = performance.now() - start;
            }
            sample.value = value; sample.sql = value.sql;
            sample.measuredMs = sample.responseBoundaryMs;
            if (asset) {
              assert.equal(value.live.status, "completed"); assert(value.live.elapsedMs <= 60_000);
              assert(value.pinnedMs <= 60_000); assert.equal(value.result.status, "ingested"); assert.equal(sample.sql.length, 12);
              // Outer boundary additionally includes cold spawn/import/connect,
              // IPC, lock-observer and journal overhead; nothing is subtracted.
              sample.pairMs = sample.measuredMs;
              sample.legSumMs = value.live.elapsedMs + value.pinnedMs;
              sample.overheadMs = sample.pairMs - sample.legSumMs;
              assert(sample.pairMs <= 42_000, "ingestion-pair-target");
              assert.equal(value.result.wireSha256, asset.sha256); assert.equal(value.result.wireBytes, asset.wire_bytes);
              assert.equal(value.result.work.downloadRequests, 1); assert.equal(value.result.work.bulkNormalizedInserts, 1);
              assert.equal(sample.pinnedTransport.sourceReads.length, 1);
              sample.databaseProvenance = (await db.reader.query("SELECT source_manifest->>'url' AS url FROM fs138.source_snapshots WHERE snapshot_id=$1", [value.result.snapshotId])).rows[0];
              assert.equal(sample.databaseProvenance.url, asset.url);
              sample.lockFinding = { samples: sample.lockObservations.length,
                openTransactionOrRowLock: sample.lockObservations.some((row: any) => row.writer.xact_start !== null ||
                  row.locks.some((lock: any) => ["tuple", "transactionid"].includes(lock.locktype))),
                note: "pg_locks omits some row locks; idle backend with no transaction excludes a transaction spanning the observed transfer." };
            } else {
              assert.equal(value.result.status, "succeeded"); assert.equal(sample.sql.length, 8);
              assert(sample.measuredMs <= 84_000, "season-feature-target");
              assert.equal(value.result.counts.rows, 1948); assert.equal(value.result.work.perExampleQueries, 0);
              const rows = (await db.reader.query(`SELECT player_id,game_id,cutoff::text,state,reasons,flags,sample_size,history,history_gaps
                FROM fs138.feature_values WHERE job_id=$1 ORDER BY player_id,game_id`, [value.result.jobId])).rows;
              sample.outputContentSha256 = sha256(Buffer.from(JSON.stringify(rows)));
              sample.output = (await db.reader.query(`SELECT count(*)::integer AS rows,
                count(*) FILTER(WHERE NOT(flags @> ARRAY['historical-availability-unverified']))::integer AS missing_flag,
                (SELECT count(*)::integer FROM fs138.feature_inputs i JOIN fs138.feature_values v USING(feature_id) WHERE v.job_id=$1) AS lineage_links
                FROM fs138.feature_values WHERE job_id=$1`, [value.result.jobId])).rows[0];
              assert.equal(sample.output.rows, 1948); assert.equal(sample.output.missing_flag, 0); assert.equal(sample.output.lineage_links, 31168);
            }
            sample.stage = "verification-cleanup"; await boundary("workload-complete");
            await cleanupRaw(store, sample); checkObserver();
          });
          sample.stage = "scratch-removed"; await boundary("scratch-removed");
          sample.peakUsedBytes = Math.max(...block.disk.filter((row: any) => row.sampleId === sample.id).map((row: any) => row.usedBytes));
          const blockGrowth = Math.max(...block.disk.map((row: any) => row.usedBytes)) - block.admission.usedBytes;
          assert(blockGrowth <= report.priorGrowthBasisBytes, "growth-exceeds-247-basis-stop-for-requalification");
          sample.verdict = "pass";
        } catch (error) {
          sample.verdict = "fail"; sample.error = { message: String(error), code: (error as any)?.code ?? null, stage: sample.stage, censored: true };
          if (sample.driverStarted !== undefined) sample.observedUntilFailureMs = performance.now() - sample.driverStarted;
          if (store && !sample.cleanup?.completed) try { await cleanupRaw(store, sample); } catch (error) { sample.cleanupError = String(error); }
          stop = true; report.verdict = "fail"; report.error = sample.error;
        } finally {
          try { await server?.close(); sample.fixtureClosed = true; } catch (error) { sample.fixtureCloseError = String(error); stop = true; report.verdict = "fail"; }
          if (destination && sample.cleanup?.completed) await rm(destination, { recursive: true });
          sample.finishedAt = new Date().toISOString(); await save();
        }
        console.log(JSON.stringify({ id: sample.id, verdict: sample.verdict, measuredMs: sample.measuredMs, liveMs: sample.value?.live?.elapsedMs,
          pinnedMs: sample.value?.pinnedMs, sql: sample.sql.length, peakUsedBytes: sample.peakUsedBytes, lockFinding: sample.lockFinding }));
        active = null;
        if (stop) break;
      }
    } catch (error) {
      stop = true; report.verdict = "fail"; block.error = { message: String(error), code: (error as any)?.code ?? null };
    } finally {
      if (timer) clearInterval(timer); await pending;
      block.peakUsedBytes = Math.max(0, ...block.disk.map((row: any) => row.usedBytes));
      block.peakGrowthBytes = block.admission ? block.peakUsedBytes - block.admission.usedBytes : null;
      await control?.end();
      if (owned && !contention) {
        try { await cli("down"); assert.equal(await ourContainers(), ""); block.teardownComplete = true; }
        catch (error) { block.teardownError = String(error); stop = true; report.verdict = "fail"; }
      }
      await lease?.close(); block.finishedAt = new Date().toISOString(); await save();
    }
  }
}
if (report.verdict === "running") {
  const features = report.samples.filter((sample: any) => sample.name === "features-2025");
  report.featureOutputParity = new Set(features.map((sample: any) => sample.outputContentSha256)).size === 1;
  report.verdict = report.samples.length === 30 && report.samples.every((sample: any) => sample.verdict === "pass") && report.featureOutputParity ? "pass" : "fail";
}
report.sourceUnchanged = (await Promise.all(inventory.map(async path => sha256(await readFile(path)) === sourceHashes[path]))).every(Boolean);
report.finalContainerAbsence = await ourContainers() === "";
report.windowEndedAt = report.finalContainerAbsence ? new Date().toISOString() : null;
report.finishedAt = new Date().toISOString();
await save();
console.log(JSON.stringify({ directory, verdict: report.verdict, samples: report.samples.length,
  teardownComplete: report.finalContainerAbsence, windowEndedAt: report.windowEndedAt, sourceUnchanged: report.sourceUnchanged }));
if (report.verdict !== "pass" || !report.finalContainerAbsence || !report.sourceUnchanged) process.exitCode = 1;
