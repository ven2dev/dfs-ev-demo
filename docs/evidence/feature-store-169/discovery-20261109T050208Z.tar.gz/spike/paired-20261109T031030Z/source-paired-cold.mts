import assert from "node:assert/strict";
import { Client } from "pg";
import { assertNoApplicationCredentials } from "@dfs-ev/db-tooling/test-support/target";
import { openLocalObjectStore } from "../../services/pipeline/src/featureStore/localObjectStore.ts";
import { perform } from "./paired-work.mts";

assert.equal(process.env.DB_TEST_LANE, "lane-3");
assert.equal(process.env.DB_TEST_TIER, "large");
assertNoApplicationCredentials(process.env);
let number = 0;
const pending = new Map<number, () => void>();
process.on("message", (message: any) => {
  if (message.kind === "ack") { pending.get(message.id)?.(); pending.delete(message.id); }
});
const notify = (stage: string, data: any = {}) => new Promise<void>(resolve => {
  const id = ++number; pending.set(id, resolve); process.send!({ kind: "stage", id, stage, ...data });
});
const input: any = await new Promise(resolve => {
  const listen = (message: any) => {
    if (message.kind !== "run") return;
    process.removeListener("message", listen); resolve(message);
  };
  process.on("message", listen);
});
const { config } = input;
assert.equal(config.port, 54349); assert.equal(config.host, "127.0.0.1");
assert.match(config.database, /^dfs_ev_test_[a-f0-9]+$/); assert.match(config.user, /^fs138_job_[a-f0-9]+$/);
assert.equal(config.password, "fs138_throwaway"); assert.equal(config.ssl, false);
const client = new Client(config);
const sql: any[] = [];
let failure;
try {
  const connectStarted = performance.now();
  await client.connect();
  const connectMs = performance.now() - connectStarted;
  const pid = (await client.query("SELECT pg_backend_pid() AS pid")).rows[0].pid;
  const store = await openLocalObjectStore(input.destination);
  await notify("connected", { writerPid: pid, connectMs, processId: process.pid });
  const value = await perform({ ...input, client, store, notify, sql });
  await new Promise<void>((resolve, reject) => process.send!({ kind: "result", value }, error => error ? reject(error) : resolve()));
} catch (error) {
  failure = error;
  await new Promise<void>(resolve => process.send!({ kind: "failure", error: String(error), code: (error as any)?.code ?? null, sql }, () => resolve()));
} finally {
  await client.end();
  process.disconnect();
}
if (failure) process.exitCode = 1;
