# #153 one-hour feasibility spike

Started 2026-10-17 19:41 PDT; hard stop 20:41 PDT.
Baseline: origin/main 12290d8e4c2aa87567bf422b58097b2ef28e7f89, Node 24.21.0, local Docker PostgreSQL 18.6, macOS.

## Design basis

Pattern: verified migrated template databases with a fresh database per test; bounded concurrency only for independently isolated scratch tests. Shared-primary and lease semantics remain serial.

Alternatives: artifact/contract caching alone removes only approximately 11.5 seconds across these two files; transaction rollback does not fit tests of commits, multiple sessions, migration history and roles. CI matrix shards remain an alternative if same-runner contention prevents the target.

Targets: complete DB integration job <=150 seconds in three consecutive CI runs; 75 Node cases and all named Vitest required cases retained; repeat mode three passes; setup migrations once per run/shard. Project benchmark standard also requests 30% headroom (105 seconds against 150). Local measurements do not prove CI performance.

Requirement reasons: fresh cloned databases prevent test-state leakage; unchanged named-case gates prevent coverage loss; historical-prefix fixtures preserve upgrade tests; cluster roles remain coordinated to prevent privilege races; cleanup prevents resource accumulation.

Assumptions: local disposable PostgreSQL 18 with create-database privileges, immutable migration inputs for one run, bounded concurrent files. No hosted/application credentials are accepted.

Spike limitations: templates are cached per file process and per requested prefix for feasibility, not globally prebuilt incremental checkpoints; exception/interruption hardening is unfinished. This does not satisfy the final setup-work budget. No production implementation, commits, pushes or CI runs are authorized by the spike.

## Reproduction

The timing-only baseline changes instrument withProof helpers; each JSONL row records file, exact case name, requested prefix, phases, nested verifier time, and total. The originals are backed up. No assertion or case is removed. Template prototype changes fixture setup only.
