import json,sys,collections
baseline=json.load(open('/tmp/dfs153-spike/baseline-vitest.json'))
r=json.load(open(sys.argv[1]))
a=collections.Counter(t['fullName'] for f in baseline['testResults'] for t in f['assertionResults'])
b=collections.Counter(t['fullName'] for f in r['testResults'] for t in f['assertionResults'])
missing=a-b
assert not missing,missing
assert r['success'] and r['numPassedTests']==136 and r['numTotalTests']==136
assert all(t['status']=='passed' for f in r['testResults'] for t in f['assertionResults'])
assert len(b)==136 and all(v==1 for v in b.values())
print('136 unique passing named Vitest cases; all 111 baseline slow-file cases preserved exactly once')
