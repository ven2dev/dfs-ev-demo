from pathlib import Path
root=Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153')
(root/'tests/db/spike-template.mjs').write_text(Path('/tmp/dfs153-spike/prototype.mjs').read_text())
p=root/'tests/db/scratch.mjs'; s=p.read_text(); Path('/tmp/dfs153-spike/scratch.mjs').write_text(s)
s=s.replace('async withDatabase(run) {','async withDatabase(run, template) {')
s=s.replace('await admin.query(`CREATE DATABASE "${name}"`);','if (template !== undefined && !/^dfs_ev_test_[a-f0-9]{20}$/.test(template)) throw Error("Invalid template");\n      await admin.query(`CREATE DATABASE "${name}"${template ? ` TEMPLATE "${template}"` : ""}`);')
p.write_text(s)
for filename in ['sourceClaims.test.ts','predictive.test.ts']:
 p=root/'tests/db'/filename; s=p.read_text(); Path('/tmp/dfs153-spike/instrumented-'+filename).write_text(s)
 s='import { afterAll } from "vitest";\nimport { templateFor, cleanupTemplates } from "./spike-template.mjs";\nafterAll(cleanupTemplates);\n'+s
 s=s.replace('const files = await checkMigrationArtifacts(); const contracts = await loadCatalogContracts(files); mark("loadArtifactsContracts");','const template = await templateFor(migrationCount); mark("templateAcquire");')
 line=next(l for l in s.splitlines() if 'await runScratchMigrations(client, { ...target, files: files.slice(0, migrationCount)' in l)
 s=s.replace(line,'      // Spike: clone already catalog-verified at the requested migration prefix.')
 # Only the helper's closure, not test callbacks.
 start=s.index('const withProof = async'); end=s.index('\n};',start)+3
 h=s[start:end]; assert h.count('    });')==1
 h=h.replace('    });','    }, template);')
 s=s[:start]+h+s[end:];p.write_text(s)
