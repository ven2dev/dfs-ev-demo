import ts from '/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153/node_modules/typescript/lib/typescript.js';
import { readFileSync,writeFileSync,renameSync } from 'node:fs';
const root='/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153/';
const file=root+'tests/db/sourceClaims.test.ts'; const source=readFileSync(file,'utf8');
const ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);
const common=[],cases=[];
for(const s of ast.statements){
 if(ts.isExpressionStatement(s)&&ts.isCallExpression(s.expression)&&s.expression.expression.getText(ast)==='it') cases.push({name:s.expression.arguments[0].text,text:s.getFullText(ast)});
 else common.push(s.getFullText(ast));
}
const times=new Map();
for(const line of readFileSync('/tmp/dfs153-spike/baseline.jsonl','utf8').trim().split('\n')){const r=JSON.parse(line); if(r.file==='sourceClaims.test.ts')times.set(r.name,(times.get(r.name)||0)+r.totalMs);}
const bins=Array.from({length:3},()=>({ms:0,cases:[]}));
for(const c of cases.sort((a,b)=>(times.get(b.name)||0)-(times.get(a.name)||0))){bins.sort((a,b)=>a.ms-b.ms); bins[0].cases.push(c);bins[0].ms+=times.get(c.name)||0;}
renameSync(file,file+'.spike-original');
for(const [i,b] of bins.entries())writeFileSync(root+`tests/db/sourceClaims.spike${i}.test.ts`,common.join('\n')+'\n'+b.cases.map(c=>c.text).join('\n'));
writeFileSync('/tmp/dfs153-spike/split-manifest.json',JSON.stringify(bins.map((b,i)=>({file:`sourceClaims.spike${i}.test.ts`,baselineMs:b.ms,names:b.cases.map(c=>c.name)})),null,2));
console.log(JSON.stringify(bins.map(b=>({tests:b.cases.length,baselineMs:b.ms}))));
