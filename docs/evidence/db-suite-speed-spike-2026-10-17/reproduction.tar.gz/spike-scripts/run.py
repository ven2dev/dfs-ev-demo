import subprocess,os,time,json,sys
root='/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153'
label=sys.argv[1]
env={'HOME':os.environ['HOME'],'PATH':'/Users/vernonneilly/.nvm/versions/node/v24.21.0/bin:/usr/local/bin:/usr/bin:/bin','TEST_DATABASE_URL':'postgresql://dfs_ev_test:dfs_ev_test@127.0.0.1:54329/dfs_ev_test','SPIKE_PROFILE_PATH':f'/tmp/dfs153-spike/{label}.jsonl','SPIKE_TEMPLATE_PATH':f'/tmp/dfs153-spike/{label}-templates.jsonl'}
args=['node','scripts/test-db.mjs','run'] if len(sys.argv)==2 else ['node','node_modules/vitest/vitest.mjs','run','--config','vitest.db.config.mts','tests/db/sourceClaims.test.ts','tests/db/predictive.test.ts','--reporter=json',f'--outputFile=/tmp/dfs153-spike/{label}-vitest.json']
start=time.monotonic()
with open(f'/tmp/dfs153-spike/{label}.log','w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
result={'label':label,'seconds':time.monotonic()-start,'exit':r.returncode,'command':args,'node':'24.21.0','commit':'12290d8e4c2aa87567bf422b58097b2ef28e7f89'}
open(f'/tmp/dfs153-spike/{label}-run.json','w').write(json.dumps(result,indent=2)+'\n'); print(json.dumps(result));sys.exit(r.returncode)
