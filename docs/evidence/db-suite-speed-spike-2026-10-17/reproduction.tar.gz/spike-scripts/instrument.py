from pathlib import Path
root=Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153')
for filename in ['sourceClaims.test.ts','predictive.test.ts']:
 p=root/'tests/db'/filename
 s=p.read_text(); Path('/tmp/dfs153-spike/'+filename).write_text(s)
 s='import { appendFileSync as spikeAppend } from "node:fs";\n'+s
 start=s.index('const withProof = async')
 end=s.index('\n};',start)+3
 h=s[start:end]
 anchor=') => {\n  const harness'
 assert anchor in h
 h=h.replace(anchor,') => {\n  const spikeStart = performance.now(); let spikeLast = spikeStart; const spike: any = { file: "'+filename+'", name: expect.getState().currentTestName, prefix: migrationCount ?? "latest", phases: {} };\n  const mark = (key: string) => { const now = performance.now(); spike.phases[key] = now - spikeLast; spikeLast = now; };\n  const harness',1)
 h=h.replace('  try {\n    const files', '  mark("adminAndTemp");\n  try {\n    const files',1)
 h=h.replace('await loadCatalogContracts(files);','await loadCatalogContracts(files); mark("loadArtifactsContracts");',1)
 h=h.replace('      const target =', '      mark("createConnect");\n      const target =',1)
 h=h.replace('await ensurePredictiveRoles(client);','await ensurePredictiveRoles(client); mark("roles");',1)
 h=h.replace('verify: createCatalogVerifier(contracts)', 'verify: async (...args: any[]) => { const t = performance.now(); try { return await (createCatalogVerifier(contracts) as any)(...args); } finally { spike.verifyMs = (spike.verifyMs ?? 0) + performance.now() - t; spike.verifyCalls = (spike.verifyCalls ?? 0) + 1; } }',1)
 h=h.replace('      await ensureHarnessSession(client);','      mark("migrationsIncludingVerify");\n      await ensureHarnessSession(client);',1)
 if filename=='sourceClaims.test.ts':
  h=h.replace('      await work({ client, artifacts, root, target, store: await createLocalPredictiveStore(client, target, artifacts) });','      const store = await createLocalPredictiveStore(client, target, artifacts); mark("sessionArtifactsStore");\n      await work({ client, artifacts, root, target, store }); mark("body");')
 else:
  h=h.replace('      await run({ client, store, root, artifacts, target });','      mark("sessionArtifactsStore");\n      await run({ client, store, root, artifacts, target }); mark("body");')
 h=h.replace('await rm(root, { recursive: true, force: true });','await rm(root, { recursive: true, force: true }); mark("cleanup"); spike.totalMs = performance.now() - spikeStart; spikeAppend(process.env.SPIKE_PROFILE_PATH!, JSON.stringify(spike)+"\\n");')
 s=s[:start]+h+s[end:]; p.write_text(s)
