import subprocess
subprocess.run(['/Users/vernonneilly/.nvm/versions/node/v24.21.0/bin/node','/tmp/dfs153-spike/split.mjs'],check=True)
subprocess.run(['python3','/tmp/dfs153-spike/apply-parallel.py'],check=True)
