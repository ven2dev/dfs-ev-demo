import subprocess,json,time
root='/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153'
# Each mutation follows a completed successful run; all operations are sequential.
steps=[('parallel-only-1','apply-parallel-only.py'),('baseline-full-2',None),('parallel-full-2','apply-all.py'),('baseline-full-3',None),('parallel-full-3','apply-all.py')]
for label,apply in steps:
 subprocess.run(['python3','/tmp/dfs153-spike/restore-baseline.py'],check=True,cwd=root)
 if apply:subprocess.run(['python3','/tmp/dfs153-spike/'+apply],check=True,cwd=root)
 subprocess.run(['python3','/tmp/dfs153-spike/run.py',label],check=True,cwd=root)
 report='/tmp/dfs153-spike/'+label+'.jsonl.report.json'
 if apply:subprocess.run(['python3','/tmp/dfs153-spike/validate-inventory.py',report],check=True,cwd=root)
