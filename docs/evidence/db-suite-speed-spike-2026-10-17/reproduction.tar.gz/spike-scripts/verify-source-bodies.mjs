import ts from '/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153/node_modules/typescript/lib/typescript.js';
import {readFileSync,readdirSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
const root='/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153/tests/db/';
function extract(file){const source=readFileSync(file,'utf8'),ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);const out=[];for(const st of ast.statements){if(ts.isExpressionStatement(st)&&ts.isCallExpression(st.expression)&&st.expression.expression.getText(ast)==='it'){out.push({name:st.expression.arguments[0].text,sha256:createHash('sha256').update(st.getText(ast)).digest('hex')});}}return out;}
const before=extract('/tmp/dfs153-spike/sourceClaims.test.ts');
const after=readdirSync(root).filter(f=>/^sourceClaims.spike[0-9]+.test.ts$/.test(f)).flatMap(f=>extract(root+f));
const sorted=a=>a.sort((x,y)=>x.name.localeCompare(y.name));
if(JSON.stringify(sorted(before))!==JSON.stringify(sorted(after)))throw Error('Test bodies changed');
writeFileSync('/tmp/dfs153-spike/source-body-hashes.json',JSON.stringify(before,null,2));console.log(before.length+' source-claims test declarations have byte-identical bodies');

function declarations(file){const source=readFileSync(file,'utf8'),ast=ts.createSourceFile(file,source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TS);return ast.statements.filter(st=>ts.isExpressionStatement(st)&&/^it[.(]/.test(st.getText(ast))).map(st=>createHash('sha256').update(st.getText(ast)).digest('hex')).sort();}
const oldPred=declarations('/tmp/dfs153-spike/predictive.test.ts'),newPred=declarations(root+'predictive.test.ts');
if(JSON.stringify(oldPred)!==JSON.stringify(newPred))throw Error('Predictive bodies changed');
console.log(oldPred.length+' predictive test declarations (32 cases) have byte-identical bodies');
