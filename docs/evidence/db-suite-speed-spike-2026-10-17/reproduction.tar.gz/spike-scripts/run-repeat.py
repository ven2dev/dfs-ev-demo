import subprocess,os,time,json,sys
root='/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153';label='concurrent-repeat-3'
env={'HOME':os.environ['HOME'],'PATH':'/Users/vernonneilly/.nvm/versions/node/v24.21.0/bin:/usr/local/bin:/usr/bin:/bin','SPIKE_PROFILE_PATH':f'/tmp/dfs153-spike/{label}.jsonl','SPIKE_TEMPLATE_PATH':f'/tmp/dfs153-spike/{label}-templates.jsonl'}
args=['npm','run','test:db:repeat','--','3'];t=time.monotonic()
with open(f'/tmp/dfs153-spike/{label}.log','w') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record={'label':label,'seconds':time.monotonic()-t,'exit':r.returncode,'command':args,'node':'24.21.0','commit':'12290d8e4c2aa87567bf422b58097b2ef28e7f89'}
open(f'/tmp/dfs153-spike/{label}-run.json','w').write(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(r.returncode)
