from pathlib import Path
r=Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153')
(r/'scripts/spike-concurrent.mjs').write_text(Path('/tmp/dfs153-spike/spike-concurrent.mjs').read_text())
p=r/'scripts/test-db.mjs';s=p.read_text().replace('if (mode === "run") return runSuite(process.env, filters);','if (mode === "run") return run(process.execPath, ["scripts/spike-concurrent.mjs"]);')
s=s.replace('await runSuite({ ...process.env, TEST_DATABASE_URL: LOCAL_TEST_DATABASE_URL }, filters)', 'await run(process.execPath, ["scripts/spike-concurrent.mjs"], { ...process.env, TEST_DATABASE_URL: LOCAL_TEST_DATABASE_URL })')
p.write_text(s)
