from pathlib import Path
r=Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153')
p=r/'scripts/test-db.mjs';s=p.read_text();Path('/tmp/dfs153-spike/test-db.mjs').write_text(s)
s=s.replace('fileURLToPath(new URL("../node_modules/vitest/vitest.mjs", import.meta.url))','fileURLToPath(new URL("./spike-vitest.mjs", import.meta.url))')
p.write_text(s)
(r/'scripts/spike-vitest.mjs').write_text(Path('/tmp/dfs153-spike/spike-vitest.mjs').read_text())
(r/'vitest.spike.config.mts').write_text('''import { defineConfig } from "vitest/config";
// Spike lane: every case in these files uses its own scratch database.
// Primary-database bootstrap and lease cases remain in the unchanged serial lane.
export default defineConfig({envDir:false,test:{environment:"node",include:["tests/db/sourceClaims.spike*.test.ts","tests/db/predictive.test.ts"],fileParallelism:true,maxWorkers:3,passWithNoTests:false,testTimeout:30000,hookTimeout:60000}});
''')
