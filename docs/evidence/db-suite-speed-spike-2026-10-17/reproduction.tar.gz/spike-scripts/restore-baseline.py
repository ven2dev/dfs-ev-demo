from pathlib import Path
r=Path('/Users/vernonneilly/Documents/VN2DEV/dfs-ev-demo-153')
for f in ['sourceClaims.test.ts','predictive.test.ts']:
 p=r/'tests/db'/f; p.write_text(Path('/tmp/dfs153-spike/instrumented-'+f).read_text())
for f in ['scratch.mjs']:(r/'tests/db'/f).write_text(Path('/tmp/dfs153-spike/'+f).read_text())
(r/'scripts/test-db.mjs').write_text(Path('/tmp/dfs153-spike/test-db.mjs').read_text())
for glob in ['tests/db/sourceClaims.spike*.test.ts','tests/db/*.spike-original','tests/db/spike-template.mjs','scripts/spike-vitest.mjs','vitest.spike.config.mts']:
 for p in r.glob(glob):p.unlink()
