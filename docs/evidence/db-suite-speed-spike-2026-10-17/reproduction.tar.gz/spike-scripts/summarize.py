import json,collections,statistics,sys
rows=[json.loads(l) for l in open(sys.argv[1])]
out={}
for f in sorted({r['file'] for r in rows}):
 a=[r for r in rows if r['file']==f]; c=collections.Counter()
 for r in a:c.update(r['phases'])
 out[f]={'helpers':len(a),'tests':len({r['name'] for r in a}),'totalSec':sum(r['totalMs'] for r in a)/1000,'phaseSec':{k:v/1000 for k,v in c.items()},'catalogVerifySec':sum(r.get('verifyMs',0) for r in a)/1000,'prefixes':dict(collections.Counter(str(r['prefix']) for r in a)),'helperP50Ms':statistics.median(r['totalMs'] for r in a)}
print(json.dumps(out,indent=2))
