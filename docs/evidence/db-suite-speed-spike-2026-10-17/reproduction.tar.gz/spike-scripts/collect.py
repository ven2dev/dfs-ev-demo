import json,glob,collections,statistics,re,datetime,hashlib
from pathlib import Path
p=Path('/tmp/dfs153-spike')
runs=[]
for f in sorted(p.glob('*-run.json')):
 r=json.loads(f.read_text());log=p/(r['label']+'.log');gates=[]
 if log.exists():
  for line in log.read_text().splitlines():
   if line.startswith('{"nodeRequiredCases"'):gates.append(json.loads(line))
 r['reportGates']=gates;runs.append(r)
profiles={}
for label in ['baseline','baseline-full-1','baseline-full-2','baseline-full-3','template-full-1','parallel-only-1','parallel-full-1','parallel-full-2','parallel-full-3','concurrent-full-1','concurrent-repeat-3']:
 f=p/(label+'.jsonl')
 if not f.exists():continue
 rows=[json.loads(l) for l in f.read_text().splitlines()]
 summaries={}
 for name in sorted({r['file'] for r in rows}):
  a=[r for r in rows if r['file']==name];c=collections.Counter()
  for r in a:c.update(r['phases'])
  summaries[name]={'helperInvocations':len(a),'distinctTestNames':len({r['name'] for r in a}),'totalHelperSeconds':sum(r['totalMs'] for r in a)/1000,'phaseSeconds':{k:v/1000 for k,v in c.items()},'catalogVerificationSeconds':sum(r.get('verifyMs',0) for r in a)/1000,'prefixCounts':dict(collections.Counter(str(r['prefix']) for r in a))}
 profiles[label]=summaries
baseline=[json.loads(l) for l in (p/'baseline.jsonl').read_text().splitlines()]
case_report=next(iter(sorted(p.glob('concurrent*.jsonl.report.json'))),None) or p/'parallel-full-1.jsonl.report.json'
report=json.loads(case_report.read_text())
repeat=[]
f=p/'concurrent-repeat-3.jsonl.runs.jsonl'
if f.exists():repeat=[json.loads(l) for l in f.read_text().splitlines()]
evidence={'issue':153,'baselineCommit':'12290d8e4c2aa87567bf422b58097b2ef28e7f89','startedAtUtc':'2026-10-18T02:41:23Z','collectedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'node':'24.21.0','host':'macOS arm64','postgres':'18.6','dockerCPUs':12,'dockerMemoryBytes':8319238144,'suiteTimingBoundary':'node scripts/test-db.mjs run; preinstalled dependencies, already-running PostgreSQL; excludes CI checkout, install, service startup and teardown'},'ciBaseline':{'runUrl':'https://github.com/ven2dev/dfs-ev-demo/actions/runs/39031183750','jobSeconds':361,'suiteStepSeconds':329,'nodeSeconds':33.863,'sourceClaimsSeconds':211.102,'predictiveSeconds':52.468,'vitestSeconds':280.88},'targets':{'ciJobSeconds':150,'consecutiveCIRuns':3,'headroomBenchmarkSeconds':105,'nodeCases':75,'vitestCases':136,'repeatCount':3,'setupBudget':'each ordered migration once per suite/shard; explicit migration behavior assertions retained separately'},'runs':runs,'profiles':profiles,'perTestBaseline':baseline,'finalRepeatRuns':repeat,'namedVitestCases':[{'file':Path(f['name']).name,'name':a['fullName'],'status':a['status']} for f in report['testResults'] for a in f['assertionResults']],'limitations':['No optimized CI runs; local elapsed times do not establish CI acceptance.','Prototype templates are per-file/per-prefix, not a run-scoped incremental template builder; final setup work budget is not proven.','Prototype does not provide production-grade interruption/failure cleanup.','All named validators remain unchanged; case body hashes are separately recorded.']}
(p/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
print(json.dumps({'runs':[(r['label'],round(r['seconds'],2),r['exit']) for r in runs],'repeatSeconds':[round(r['seconds'],2) for r in repeat]},indent=2))
