import subprocess
node='/Users/vernonneilly/.nvm/versions/node/v24.21.0/bin/node'
for args in [['python3','/tmp/dfs153-spike/apply-template.py'],[node,'/tmp/dfs153-spike/split.mjs'],['python3','/tmp/dfs153-spike/apply-parallel.py']]:subprocess.run(args,check=True)
